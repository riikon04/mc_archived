#mc-build WASD content
stopsound @a * minecraft:entity.player.attack.crit
stopsound @a * minecraft:entity.player.attack.knockback
stopsound @a * minecraft:entity.player.attack.nodamage
stopsound @a * minecraft:entity.player.attack.strong
stopsound @a * minecraft:entity.player.attack.sweep
stopsound @a * minecraft:entity.player.attack.weak