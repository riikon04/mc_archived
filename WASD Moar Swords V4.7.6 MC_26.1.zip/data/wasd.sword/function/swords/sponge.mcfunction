#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
fill ~3 ~1 ~3 ~-3 ~-1 ~-3 air replace #wasd.tags:water_blocks
playsound minecraft:entity.cod.flop player @a ~ ~ ~ 1 1.6
playsound minecraft:entity.cod.flop player @a ~ ~ ~ 1 1.6
playsound minecraft:entity.cod.flop player @a ~ ~ ~ 1 1.6
playsound minecraft:entity.cod.flop player @a ~ ~ ~ 1 1.6
playsound minecraft:entity.cod.flop player @a ~ ~ ~ 1 1.6
playsound minecraft:entity.cod.flop player @a ~ ~ ~ 1 1.6