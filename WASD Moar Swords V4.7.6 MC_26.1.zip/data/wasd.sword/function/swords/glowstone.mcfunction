#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
effect give @s minecraft:glowing 10 0 true
particle minecraft:flash{color:[1.000,0.969,0.000,1.00]} ~ ~1 ~
playsound minecraft:block.beacon.activate player @a ~ ~ ~ 1 2