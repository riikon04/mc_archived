#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
effect give @s minecraft:poison 3 1 false
playsound minecraft:entity.puffer_fish.sting player @a ~ ~ ~ 1 1