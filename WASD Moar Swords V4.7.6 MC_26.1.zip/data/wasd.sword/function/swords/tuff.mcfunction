#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
playsound block.tuff.break player @a ~ ~ ~ 1 1
playsound block.tuff.break player @a ~ ~ ~ 1 1
playsound block.tuff.break player @a ~ ~ ~ 1 1