#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
playsound minecraft:entity.chicken.egg player @a ~ ~ ~ 2 0.7
playsound minecraft:entity.chicken.egg player @a ~ ~ ~ 2 0.7
playsound minecraft:entity.chicken.egg player @a ~ ~ ~ 2 0.7
summon minecraft:egg ~ ~3 ~