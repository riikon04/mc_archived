#mc-build WASD content
#new swords
#summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:stone_sword",Count:1b,tag:{display:{Name:{"text":"Wither Sword","italic":false}, Lore:[{"text":"Makes you immune to potions effects.","color":"blue","italic":false}]},CustomModelData:6371004,wasd_held_sword:1b,wasd_sword:1b,wasd.sword_type:52b,AttributeModifiers:[{AttributeName:"generic.attack_damage",Name:"generic.attack_damage",Amount:8,Operation:0,UUID:[I; -192596, -61963, -161679, -10288428],Slot:"mainhand"},{AttributeName:"generic.attack_speed",Name:"generic.attack_speed",Amount:-2.5,Operation:0,UUID:[I; -192596, -61963, -161679, -10288428],Slot:"mainhand"}]}}}
#summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:iron_sword",Count:1b,tag:{display:{Name:{"text":"Crying Obsidian Sword","italic":false}, Lore:[{"text":"Makes mobs sometimes drop ghast tears.","color":"blue","italic":false}]},CustomModelData:6370014,wasd_sword:1b,wasd.sword_type:54b}}}
loot give @s loot wasd.sword:items/patron/granite
loot give @s loot wasd.sword:items/patron/andesite
loot give @s loot wasd.sword:items/patron/bed
loot give @s loot wasd.sword:items/patron/xp_bottle
loot give @s loot wasd.sword:items/patron/calcite
loot give @s loot wasd.sword:items/patron/coral_fan
loot give @s loot wasd.sword:items/patron/furnace
loot give @s loot wasd.sword:items/patron/door
loot give @s loot wasd.sword:items/patron/blackstone
loot give @s loot wasd.sword:items/patron/mud
loot give @s loot wasd.sword:items/patron/packed_mud
loot give @s loot wasd.sword:items/patron/basalt
loot give @s loot wasd.sword:items/patron/gilded_blackstone
loot give @s loot wasd.sword:items/patron/terracotta
loot give @s loot wasd.sword:items/patron/tall_grass
loot give @s loot wasd.sword:items/patron/podzol
loot give @s loot wasd.sword:items/patron/gravel
loot give @s loot wasd.sword:items/patron/blue_ice
loot give @s loot wasd.sword:items/patron/soul_soil
loot give @s loot wasd.sword:items/patron/bone_block
loot give @s loot wasd.sword:items/patron/brown_mushroom
loot give @s loot wasd.sword:items/patron/red_mushroom
loot give @s loot wasd.sword:items/patron/warped_fungus
loot give @s loot wasd.sword:items/patron/crimson_fungus
loot give @s loot wasd.sword:items/patron/fern
loot give @s loot wasd.sword:items/patron/dead_bush
loot give @s loot wasd.sword:items/patron/torchflower
loot give @s loot wasd.sword:items/patron/wither_rose
loot give @s loot wasd.sword:items/patron/spore_blossom
loot give @s loot wasd.sword:items/patron/sweet_berries
loot give @s loot wasd.sword:items/patron/nether_wart
loot give @s loot wasd.sword:items/patron/lily_pad
loot give @s loot wasd.sword:items/patron/kelp
loot give @s loot wasd.sword:items/patron/dried_kelp
loot give @s loot wasd.sword:items/patron/bee_nest
loot give @s loot wasd.sword:items/patron/honey_comb