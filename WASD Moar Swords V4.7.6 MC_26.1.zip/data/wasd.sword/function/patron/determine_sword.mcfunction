#mc-build WASD content
execute as @s[scores={wasd.sword_type=131}] run function wasd.sword:patron/swords/bed
execute as @s[scores={wasd.sword_type=132}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/xp_bottle
#execute as @s[scores={wasd.sword_type=133}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/none
execute as @s[scores={wasd.sword_type=134}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword_dev:patron/swords/coral_fan
execute as @s[scores={wasd.sword_type=135}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword_dev:patron/swords/furnace
execute as @s[scores={wasd.sword_type=136}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/door
#execute as @s[scores={wasd.sword_type=137}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/none
execute as @s[scores={wasd.sword_type=138}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/mud
execute as @s[scores={wasd.sword_type=139}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/packed_mud
execute as @s[scores={wasd.sword_type=140}] run function wasd.sword:patron/swords/basalt
execute as @s[scores={wasd.sword_type=141}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/gilded_blackstone
execute as @s[scores={wasd.sword_type=143}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/tall_grass
execute as @s[scores={wasd.sword_type=144}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/podzol
execute as @s[scores={wasd.sword_type=145}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/gravel
execute as @s[scores={wasd.sword_type=146}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/blue_ice
execute as @s[scores={wasd.sword_type=147}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/soul_soil_hit
execute as @s[scores={wasd.sword_type=148}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/bone_block
execute as @s[scores={wasd.sword_type=149}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/brown_mushroom
execute as @s[scores={wasd.sword_type=150}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/red_mushroom
execute as @s[scores={wasd.sword_type=151}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/warped_fungus
execute as @s[scores={wasd.sword_type=152}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/crimson_fungus
execute as @s[scores={wasd.sword_type=153}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/fern
execute as @s[scores={wasd.sword_type=154}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/dead_bush
execute as @s[scores={wasd.sword_type=155}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/torchflower
execute as @s[scores={wasd.sword_type=156}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/wither_rose
execute as @s[scores={wasd.sword_type=157}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/spore_blossom
execute as @s[scores={wasd.sword_type=158}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/sweet_berries
execute as @s[scores={wasd.sword_type=159}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/nether_wart
execute as @s[scores={wasd.sword_type=160}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/lily_pad
execute as @s[scores={wasd.sword_type=161}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/kelp
execute as @s[scores={wasd.sword_type=162}] run function wasd.sword:patron/swords/dried_kelp
execute as @s[scores={wasd.sword_type=163}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/bee_nest
execute as @s[scores={wasd.sword_type=164}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/honey_comb
execute as @s[scores={wasd.sword_type=165}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/froglight
execute as @s[scores={wasd.sword_type=168}] run function wasd.sword:patron/swords/sculk
execute as @s[scores={wasd.sword_type=169}] run function wasd.sword:patron/swords/sculk_catalyst
execute as @s[scores={wasd.sword_type=170}] run function wasd.sword:patron/swords/sculk_sensor
#execute as @s[scores={wasd.sword_type=171}] run function wasd.sword:patron/swords/echo_shard
execute as @s[scores={wasd.sword_type=172}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/end_rod
execute as @s[scores={wasd.sword_type=173}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/decorated_pot
execute as @s[scores={wasd.sword_type=175}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword_dev:patron/swords/item_frame
execute as @s[scores={wasd.sword_type=174}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/armor_stand
execute as @s[scores={wasd.sword_type=175}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword_dev:patron/swords/
execute as @s[scores={wasd.sword_type=176}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/painting
execute as @s[scores={wasd.sword_type=177}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword_dev:patron/swords/lectern
execute as @s[scores={wasd.sword_type=178}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/minecart
execute as @s[scores={wasd.sword_type=179}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/
execute as @s[scores={wasd.sword_type=180}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/