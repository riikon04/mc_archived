#mc-build WASD content
$summon falling_block ~ ~ ~ {BlockState:{Name:"$(id)"},Time:1,Tags:["wasd.gravel_sword"]}
setblock ~ ~ ~ air