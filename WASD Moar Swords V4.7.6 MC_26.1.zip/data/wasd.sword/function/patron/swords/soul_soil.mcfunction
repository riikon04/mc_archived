#mc-build WASD content
execute if block ~ ~-0.1 ~ #minecraft:soul_speed_blocks run function wasd.sword:patron/swords/zzz/9