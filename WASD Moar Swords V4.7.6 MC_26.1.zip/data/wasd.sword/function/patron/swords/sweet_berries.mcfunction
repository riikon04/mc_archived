#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
playsound minecraft:block.sweet_berry_bush.break player @a ~ ~ ~ 1 1
particle falling_dust{block_state:{Name:"minecraft:red_concrete"}} ~ ~1 ~ 0.3 0.5 0.3 1 10
particle falling_dust{block_state:{Name:"minecraft:dried_kelp_block"}} ~ ~1 ~ 0.3 0.5 0.3 1 10
execute if block ~ ~-1 ~ #wasd.tags:plant_soil if block ~ ~ ~ #wasd.tags:air run function wasd.sword:patron/swords/zzz/14