#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
playsound minecraft:block.stem.break player @a ~ ~ ~ 1 1
particle minecraft:falling_dust{block_state:{Name:"minecraft:orange_wool"}} ~ ~1 ~ 0.3 0.5 0.3 1 5 normal
particle minecraft:falling_dust{block_state:{Name:"minecraft:nether_wart_block"}} ~ ~1 ~ 0.3 0.5 0.3 1 10 normal
execute as @s[type=#wasd.tags:piglins] run function wasd.sword:patron/swords/zzz/11