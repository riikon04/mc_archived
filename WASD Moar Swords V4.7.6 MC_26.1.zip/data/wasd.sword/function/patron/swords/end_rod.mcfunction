#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
playsound minecraft:entity.shulker.shoot player @a ~ ~ ~ 1 1.2
particle minecraft:end_rod ~ ~1 ~ 0.2 0.5 0.2 0.05 30 normal