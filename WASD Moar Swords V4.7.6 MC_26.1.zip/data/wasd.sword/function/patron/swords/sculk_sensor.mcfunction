#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
playsound minecraft:block.sculk_sensor.clicking player @a ~ ~ ~ 1 1
playsound minecraft:block.sculk_sensor.clicking player @a ~ ~ ~ 1 1
playsound minecraft:block.sculk_sensor.clicking player @a ~ ~ ~ 1 1
effect give @e[type=#wasd.tags:mobs_player,distance=..12,tag=!wasd.attacker] minecraft:glowing 5 0 true