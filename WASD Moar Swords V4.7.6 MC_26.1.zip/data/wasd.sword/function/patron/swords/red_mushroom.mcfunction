#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
function wasd.sword:patron/swords/summon_mushroom
particle block{block_state:{Name:"minecraft:red_mushroom_block"}} ~ ~1 ~ 0.2 0.3 0.2 1 50 normal
particle block{block_state:{Name:"minecraft:mushroom_stem"}} ~ ~1 ~ 0.2 0.3 0.2 1 10 normal
playsound minecraft:block.fungus.break player @a ~ ~ ~ 1 0.8