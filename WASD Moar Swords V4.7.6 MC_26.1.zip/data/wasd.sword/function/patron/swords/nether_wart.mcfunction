#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
particle entity_effect{color:[1.000, 0.098, 0.098, 1.00]} ~ ~1 ~ 0.3 0.5 0.3 0.05 5
particle entity_effect{color:[1.000, 1.000, 0.090, 1.00]} ~ ~1 ~ 0.3 0.5 0.3 0.05 5
particle entity_effect{color:[0.220, 1.000, 0.325, 1.00]} ~ ~1 ~ 0.3 0.5 0.3 0.05 5
particle entity_effect{color:[0.212, 1.000, 1.000, 1.00]} ~ ~1 ~ 0.3 0.5 0.3 0.05 5
particle entity_effect{color:[0.251, 0.302, 1.000, 1.00]} ~ ~1 ~ 0.3 0.5 0.3 0.05 5
particle entity_effect{color:[1.000, 0.259, 1.000, 1.00]} ~ ~1 ~ 0.3 0.5 0.3 0.05 5
particle entity_effect{color:[1.000, 0.620, 0.847, 1.00]} ~ ~1 ~ 0.3 0.5 0.3 0.05 5
playsound minecraft:entity.generic.drink player @a ~ ~ ~ 0.5 0.8
playsound minecraft:block.brewing_stand.brew player @a ~ ~ ~ 0.5 1
function wasd.sword:patron/swords/zzz/34