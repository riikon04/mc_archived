#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
playsound minecraft:item.armor.equip_generic player @a ~ ~ ~ 1 1
execute store result score @s wasd.temp run attribute @s minecraft:armor get
title @p[tag=wasd.attacker] actionbar [{"color":"blue","text":"Armor: "},{"score":{"name":"@s","objective":"wasd.temp"}}]