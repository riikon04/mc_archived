#mc-build WASD content
execute if block ~ ~ ~ #wasd.tags:water_blocks run function wasd.sword:patron/swords/zzz/18