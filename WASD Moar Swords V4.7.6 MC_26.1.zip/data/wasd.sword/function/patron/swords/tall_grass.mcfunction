#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
tag @s add wasd.bleeding
tag @s add wasd.lib_entity_tick
scoreboard players add @s wasd.bleeding 80
playsound minecraft:entity.wind_charge.wind_burst player @a ~ ~ ~ 1 1.5