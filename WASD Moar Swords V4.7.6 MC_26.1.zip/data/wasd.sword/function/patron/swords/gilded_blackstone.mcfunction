#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
particle block{block_state:{Name:"minecraft:blackstone"}} ~ ~1 ~ 0.2 0.5 0.2 1 10 normal
playsound minecraft:block.gilded_blackstone.break player @a ~ ~ ~ 1
execute store result score @s wasd.rng run random value 1..15
execute as @s[scores={wasd.rng=1}] run function wasd.sword:patron/swords/zzz/6