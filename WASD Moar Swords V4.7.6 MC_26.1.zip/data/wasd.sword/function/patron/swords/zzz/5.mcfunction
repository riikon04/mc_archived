#mc-build WASD content
playsound minecraft:block.wooden_door.close player @a ~ ~ ~ 1 0.7
playsound minecraft:block.wooden_door.close player @a ~ ~ ~ 1 0.7
playsound minecraft:block.wooden_door.close player @a ~ ~ ~ 1 0.7
particle minecraft:gust ~ ~0.8 ~ 0.4 0.3 0.4 0 10