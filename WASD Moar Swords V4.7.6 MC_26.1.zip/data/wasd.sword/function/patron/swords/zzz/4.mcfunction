#mc-build WASD content
playsound minecraft:block.wooden_door.close player @a ~ ~ ~ 1 1.2
playsound minecraft:block.wooden_door.close player @a ~ ~ ~ 1 1.2
playsound minecraft:block.wooden_door.close player @a ~ ~ ~ 1 1.2
particle minecraft:gust ~ ~0.3 ~ 0.2 0.3 0.2 0 7