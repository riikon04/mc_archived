#mc-build WASD content
function wasd.sword:patron/swords/gravel_spawn_block with entity @s Item
kill @s