#mc-build WASD content
playsound minecraft:block.wooden_door.close player @a ~ ~ ~ 1 1
playsound minecraft:block.wooden_door.close player @a ~ ~ ~ 1 1
playsound minecraft:block.wooden_door.close player @a ~ ~ ~ 1 1
particle minecraft:gust ~ ~1 ~ 0.3 0.3 0.3 0 5