#mc-build WASD content
scoreboard players add @s wasd.echo_sword_timer 1
execute as @s[scores={wasd.echo_sword_timer=1}] run function wasd.sword:patron/swords/zzz/26
execute as @s[scores={wasd.echo_sword_timer=2}] run function wasd.sword:patron/swords/zzz/27
execute as @s[scores={wasd.echo_sword_timer=3}] run function wasd.sword:patron/swords/zzz/28
execute as @s[scores={wasd.echo_sword_timer=4}] run function wasd.sword:patron/swords/zzz/29
execute as @s[scores={wasd.echo_sword_timer=5}] run function wasd.sword:patron/swords/zzz/30