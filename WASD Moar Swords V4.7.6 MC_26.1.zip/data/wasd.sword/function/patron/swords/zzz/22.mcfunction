#mc-build WASD content
execute store result score @s wasd.temp run data get entity @s Value 1
scoreboard players operation @p[tag=wasd.attacker] wasd.temp2 += @s wasd.temp
particle minecraft:sculk_soul ~ ~0.3 ~ 0.1 0.1 0.1 0 3 normal
playsound minecraft:block.sculk_catalyst.bloom player @a ~ ~ ~ 1 1
kill @s