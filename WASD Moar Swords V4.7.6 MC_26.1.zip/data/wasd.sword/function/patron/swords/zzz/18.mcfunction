#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
particle minecraft:falling_dust{block_state:{Name:"minecraft:lime_concrete"}} ~ ~1 ~ 0.3 0.5 0.3 0.05 15
particle minecraft:falling_dust{block_state:{Name:"minecraft:dried_kelp_block"}} ~ ~1 ~ 0.3 0.5 0.3 0.05 15
playsound minecraft:block.sponge.absorb player @a ~ ~ ~ 1 1.7
playsound minecraft:block.sponge.absorb player @a ~ ~ ~ 1 1.3
effect give @s minecraft:slowness 10 2 false