#mc-build WASD content
particle minecraft:bubble_pop ~ ~1 ~ 0.3 0.5 0.3 0 50
execute positioned over world_surface run function wasd.lib:detection/horizontal/fixed/7x7
execute as @e[tag=wasd.location,limit=1,sort=random] at @s if block ~ ~-1 ~ water if block ~ ~ ~ #wasd.tags:air run function wasd.sword:patron/swords/zzz/16
execute as @e[tag=wasd.location,limit=1,sort=random] at @s if block ~ ~-1 ~ water if block ~ ~ ~ #wasd.tags:air run function wasd.sword:patron/swords/zzz/17
kill @e[tag=wasd.location]