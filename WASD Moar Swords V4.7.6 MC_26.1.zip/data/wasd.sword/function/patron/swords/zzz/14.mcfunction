#mc-build WASD content
execute store result score @s wasd.rng run random value 0..10
execute as @s[scores={wasd.rng=0}] run setblock ~ ~ ~ minecraft:sweet_berry_bush[age=0]
execute as @s[scores={wasd.rng=1}] run setblock ~ ~ ~ minecraft:sweet_berry_bush[age=1]
execute as @s[scores={wasd.rng=2}] run setblock ~ ~ ~ minecraft:sweet_berry_bush[age=2]
execute as @s[scores={wasd.rng=3}] run setblock ~ ~ ~ minecraft:sweet_berry_bush[age=3]