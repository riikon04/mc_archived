#mc-build WASD content
scoreboard players reset @s wasd.temp2
execute as @e[type=minecraft:experience_orb,distance=..7] at @s run function wasd.sword:patron/swords/zzz/22
scoreboard players operation @s wasd.temp2 /= 2 wasd.constants
effect give @s[scores={wasd.temp2=1}] minecraft:regeneration 2 1 true
effect give @s[scores={wasd.temp2=2}] minecraft:regeneration 4 1 true
effect give @s[scores={wasd.temp2=3}] minecraft:regeneration 6 1 true
effect give @s[scores={wasd.temp2=4}] minecraft:regeneration 8 1 true
effect give @s[scores={wasd.temp2=5}] minecraft:regeneration 10 1 true
effect give @s[scores={wasd.temp2=6}] minecraft:regeneration 12 1 true
effect give @s[scores={wasd.temp2=7}] minecraft:regeneration 14 1 true
effect give @s[scores={wasd.temp2=8}] minecraft:regeneration 16 1 true
effect give @s[scores={wasd.temp2=9}] minecraft:regeneration 18 1 true
effect give @s[scores={wasd.temp2=10}] minecraft:regeneration 20 1 true
effect give @s[scores={wasd.temp2=11}] minecraft:regeneration 22 1 true
effect give @s[scores={wasd.temp2=12}] minecraft:regeneration 24 1 true
effect give @s[scores={wasd.temp2=13}] minecraft:regeneration 26 1 true
effect give @s[scores={wasd.temp2=14}] minecraft:regeneration 28 1 true
effect give @s[scores={wasd.temp2=15}] minecraft:regeneration 30 1 true
effect give @s[scores={wasd.temp2=16}] minecraft:regeneration 32 1 true
effect give @s[scores={wasd.temp2=17}] minecraft:regeneration 34 1 true
effect give @s[scores={wasd.temp2=18}] minecraft:regeneration 36 1 true
effect give @s[scores={wasd.temp2=19}] minecraft:regeneration 38 1 true
effect give @s[scores={wasd.temp2=20..}] minecraft:regeneration 42 1 true