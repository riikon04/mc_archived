#mc-build WASD content
playsound minecraft:entity.warden.sonic_charge player @a ~ ~ ~ 1 1.5
particle minecraft:sonic_boom