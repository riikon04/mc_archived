#mc-build WASD content
setblock ~ ~ ~ lily_pad
particle dust{color:[0.0, 0.5, 0.0], scale:2.0} ~ ~-0.5 ~ 0.3 0 0.3 0 5 normal