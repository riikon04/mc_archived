#mc-build WASD content
playsound minecraft:block.sculk_catalyst.break player @a ~ ~ ~ 1 1
particle minecraft:sculk_soul ~ ~1 ~ 0.3 0.5 0.3 0.05 5