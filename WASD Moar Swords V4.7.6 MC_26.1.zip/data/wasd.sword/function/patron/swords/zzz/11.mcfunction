#mc-build WASD content
damage @s 12 minecraft:player_attack by @p[tag=wasd.attacker]
playsound minecraft:block.stem.break player @a ~ ~ ~ 10 0.5
playsound minecraft:block.stem.break player @a ~ ~ ~ 10 1
playsound minecraft:block.stem.break player @a ~ ~ ~ 10 1.5
particle falling_dust{block_state:{Name:"minecraft:nether_wart_block"}} ~ ~1 ~ 0.3 0.5 0.3 1 50