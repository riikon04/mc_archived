#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
playsound minecraft:block.basalt.break player @a ^ ^ ^3 1 1
playsound minecraft:block.basalt.break player @a ^ ^ ^3 1 1
particle minecraft:block{block_state:{Name:"minecraft:basalt"}} ~ ~0.3 ~ 0.3 0.2 0.3 1 20
effect give @s minecraft:fire_resistance 15 0 false