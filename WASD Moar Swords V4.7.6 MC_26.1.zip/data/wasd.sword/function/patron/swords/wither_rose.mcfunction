#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
particle minecraft:falling_dust{block_state:{Name:"minecraft:gray_concrete"}} ~ ~1 ~ 0.3 0.5 0.3 0.05 15
particle minecraft:falling_dust{block_state:{Name:"minecraft:dried_kelp_block"}} ~ ~1 ~ 0.3 0.5 0.3 0.05 15
playsound minecraft:entity.evoker.cast_spell player @a ~ ~ ~ 1 1.7
effect give @s minecraft:wither 10 0 false