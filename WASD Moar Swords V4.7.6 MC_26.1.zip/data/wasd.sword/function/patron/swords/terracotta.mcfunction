#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
fill ~5 ~5 ~5 ~-5 ~-5 ~-5 air replace #minecraft:beds