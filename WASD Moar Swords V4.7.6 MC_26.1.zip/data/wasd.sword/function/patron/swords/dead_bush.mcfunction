#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
playsound block.grass.break player @a ~ ~ ~ 1 0.6
particle dust{color:[0.980,0.859,0.518],scale:1} ~ ~1 ~ 0.3 0.5 0.3 1 5
execute if biome ~ ~ ~ minecraft:desert run function wasd.sword:patron/swords/zzz/13