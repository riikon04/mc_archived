#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
playsound minecraft:entity.evoker.prepare_attack player @a ~ ~ ~ 0.2 0.7
particle minecraft:soul ~ ~1 ~ 0.3 0.5 0.3 0.1 20