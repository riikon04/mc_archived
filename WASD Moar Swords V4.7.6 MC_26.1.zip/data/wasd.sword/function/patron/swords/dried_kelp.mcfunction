#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
playsound block.sponge.break player @a ~ ~ ~ 1 0.5
execute store result score @s wasd.rng run random value 1..5
execute as @s[scores={wasd.rng=1}] run function wasd.sword:patron/swords/zzz/19