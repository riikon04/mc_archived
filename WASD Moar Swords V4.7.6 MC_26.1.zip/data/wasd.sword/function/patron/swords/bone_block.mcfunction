#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
loot spawn ~ ~1 ~ loot wasd.sword:bone_block
playsound block.bone_block.break player @a ~ ~ ~ 1 1
playsound block.bone_block.break player @a ~ ~ ~ 1 1
playsound block.bone_block.break player @a ~ ~ ~ 1 1
particle minecraft:falling_dust{block_state:{Name:"minecraft:bone_block"}} ~ ~1 ~ 0.3 0.5 0.3 1 15 normal
particle minecraft:falling_dust{block_state:{Name:"minecraft:white_concrete"}} ~ ~1 ~ 0.3 0.5 0.3 1 30 normal