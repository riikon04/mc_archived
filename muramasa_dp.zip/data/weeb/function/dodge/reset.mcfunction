scoreboard players reset @s weeb.shift
advancement revoke @s only weeb:release_shift