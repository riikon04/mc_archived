execute if score @s weeb.dodgeCD matches 1.. run scoreboard players remove @s weeb.dodgeCD 1
advancement revoke @s only weeb:dodge_cd