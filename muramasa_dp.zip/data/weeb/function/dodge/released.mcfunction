# this function runs when shift button is released
execute if score @s weeb.dodgeCD matches 1.. run return run function weeb:dodge/reset
execute if predicate weeb:no_input run return run function weeb:dodge/reset

# weeb.dodge gives damage immunity in quick step enchant
scoreboard players reset @s weeb.dodge
execute unless score @s weeb.shift matches 4.. if entity @s[predicate=weeb:holding_sword] run function weeb:dodge/set_values

function weeb:dodge/reset