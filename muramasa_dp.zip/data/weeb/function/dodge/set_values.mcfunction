advancement revoke @s only weeb:dodge_cd
scoreboard players set @s weeb.dodge 1
scoreboard players set @s weeb.dodgeCD 7
playsound minecraft:entity.wind_charge.wind_burst master @a ~ ~ ~ 0.5 0.6