# ran by quick step enchant
scoreboard players add @s weeb.dodge 1
particle minecraft:smoke ~ ~ ~ 0 0 0 0.05 10

# controls amount of iframes from dodge
execute if score @s weeb.dodge matches 6.. run scoreboard players reset @s weeb.dodge