scoreboard players add @s[gamemode=!creative,gamemode=!spectator] weeb.curseInvTime 1

execute if score @s[gamemode=!creative,gamemode=!spectator] weeb.curseInvTime matches 600..1200 run playsound minecraft:particle.soul_escape master @a ~ ~ ~ 0.75 0.9
execute if score @s[gamemode=!creative,gamemode=!spectator] weeb.curseInvTime matches 1200..1800 run playsound minecraft:particle.soul_escape master @a ~ ~ ~ 1.5 0.9
execute if score @s[gamemode=!creative,gamemode=!spectator] weeb.curseInvTime matches 1800.. run function weeb:curse/active

advancement revoke @s only weeb:curse_tick