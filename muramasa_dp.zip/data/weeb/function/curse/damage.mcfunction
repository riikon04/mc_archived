damage @s 4 out_of_world
scoreboard players reset @s weeb.curseDmgTime