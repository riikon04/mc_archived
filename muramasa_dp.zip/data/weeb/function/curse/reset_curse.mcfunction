scoreboard players reset @s weeb.curseInvTime
scoreboard players reset @s weeb.curseDmgTime
advancement revoke @s only weeb:reset_curse
advancement revoke @s only weeb:curse_tick