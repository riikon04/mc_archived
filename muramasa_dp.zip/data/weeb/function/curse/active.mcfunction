playsound minecraft:particle.soul_escape master @a ~ ~ ~ 3 0.9
scoreboard players add @s weeb.curseDmgTime 1
execute if score @s weeb.curseDmgTime matches 20.. run function weeb:curse/damage