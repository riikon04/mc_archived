execute as @a[tag=!hasWeebID] run function weeb:set_id

execute as @e[type=interaction,tag=weebInteract] at @s run function weeb:temple/interact_main