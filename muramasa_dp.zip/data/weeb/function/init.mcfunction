scoreboard objectives add weeb.id dummy
scoreboard objectives add weeb.objID dummy
scoreboard objectives add weeb.temp dummy
scoreboard objectives add weeb.slashTime dummy
scoreboard objectives add weeb.dodge dummy
scoreboard objectives add weeb.dodgeCD dummy
scoreboard objectives add weeb.charge dummy
scoreboard objectives add weeb.const dummy
scoreboard objectives add weeb.shift minecraft.custom:minecraft.sneak_time
scoreboard objectives add weeb.curseInvTime dummy
scoreboard objectives add weeb.curseDmgTime dummy
scoreboard objectives add weeb.block dummy
scoreboard objectives add weeb.blockCD dummy

scoreboard players set #-1 weeb.const -1

schedule function weeb:slash/loop 20t append
schedule function weeb:flurry/loop 20t append