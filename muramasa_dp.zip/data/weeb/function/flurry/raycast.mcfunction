scoreboard players remove #weebRange weeb.temp 1

execute positioned ~-0.5 ~-0.5 ~-0.5 if entity @e[type=#weeb:targets,predicate=!weeb:match_id,dx=0,dy=0,dz=0] positioned ~0.5 ~0.5 ~0.5 summon marker run return run function weeb:flurry/setup_anchor
execute unless block ^ ^ ^1 #weeb:passable summon marker run return run function weeb:flurry/setup_anchor
execute if score #weebRange weeb.temp matches ..0 summon marker run return run function weeb:flurry/setup_anchor

execute if score #weebRange weeb.temp matches 1.. positioned ^ ^ ^1 run function weeb:flurry/raycast