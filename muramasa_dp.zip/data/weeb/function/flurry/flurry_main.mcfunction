scoreboard players operation #weebSearch weeb.objID = @s weeb.objID
scoreboard players operation #weebSearch weeb.id = @s weeb.id

scoreboard players add @s weeb.temp 1
execute if score @s weeb.temp matches 16.. run return run function weeb:flurry/clear

scoreboard players add @s weeb.slashTime 1
execute if score @s weeb.slashTime matches 4.. run function weeb:flurry/slash

schedule function weeb:flurry/loop 1t append