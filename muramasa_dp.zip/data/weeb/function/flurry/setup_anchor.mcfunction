scoreboard players reset #weebRange weeb.temp

scoreboard players operation @s weeb.id = #weebSearch weeb.id
scoreboard players operation @s weeb.objID = #weebSearch weeb.objID
scoreboard players set @s weeb.slashTime 5

tag @s add weeb
tag @s add flurryAnchor

schedule function weeb:flurry/loop 1t append