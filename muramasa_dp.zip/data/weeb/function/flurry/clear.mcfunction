scoreboard players operation #weebSearch weeb.objID = @s weeb.objID
kill @e[type=item_display,tag=flurry,predicate=weeb:match_obj]
kill @s