#if not charged, fail
scoreboard players reset @s weeb.temp
execute unless score @s weeb.charge matches 10.. run return run scoreboard players reset @s weeb.charge

#charged
playsound minecraft:item.spear.lunge_3 master @a ~ ~ ~ 0.8 0.8
scoreboard players reset @s weeb.charge
scoreboard players add #objID weeb.objID 1
scoreboard players operation #weebSearch weeb.objID = #objID weeb.objID
scoreboard players operation #weebSearch weeb.id = @s weeb.id
scoreboard players set #weebRange weeb.temp 6
execute anchored eyes positioned ^ ^ ^ anchored feet run function weeb:flurry/raycast