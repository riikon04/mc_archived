scoreboard players add @s[predicate=weeb:press_crouch] weeb.charge 1
scoreboard players add @s weeb.temp 1
execute if score @s weeb.temp matches 1 run playsound minecraft:item.spear_wood.use master @a ~ ~ ~ 1 0.4
execute if score @s weeb.charge matches 10 run playsound minecraft:entity.arrow.hit_player master @a ~ ~ ~ 1 2
execute if score @s weeb.charge matches 10 run scoreboard players add @s weeb.charge 1