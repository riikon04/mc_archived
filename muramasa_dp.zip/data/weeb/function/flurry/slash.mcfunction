scoreboard players reset @s weeb.slashTime
playsound minecraft:item.spear.lunge_1 master @a ~ ~ ~ 1 0.7

function weeb:slash/rand/start
function weeb:slash/rand/start
function weeb:slash/rand/start