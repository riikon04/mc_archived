execute if entity @p[tag=thisPlayer,gamemode=!survival,gamemode=!adventure] run return run data remove entity @s interaction.player

execute on passengers run kill @s
kill @s