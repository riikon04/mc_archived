function weeb:give_sword
tag @s add thisPlayer
execute as @n[type=interaction,tag=thisInteract] at @s run function weeb:temple/clear_interaction
tag @s remove thisPlayer