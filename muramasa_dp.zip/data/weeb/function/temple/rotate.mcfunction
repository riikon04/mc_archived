#tag @s add rotated
execute if block ~ ~-1 ~ birch_stairs[facing=west] on passengers at @s run rotate @s 0 ~
execute if block ~ ~-1 ~ birch_stairs[facing=north] on passengers at @s run rotate @s 90 ~
execute if block ~ ~-1 ~ birch_stairs[facing=east] on passengers at @s run rotate @s 180 ~
execute if block ~ ~-1 ~ birch_stairs[facing=south] on passengers at @s run rotate @s 270 ~