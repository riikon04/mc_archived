summon item_display ~ ~ ~ {Rotation:[0F,-89F],Tags:["weeb","newDisplay"],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,1f],scale:[1f,1f,1f]},item:{id:"minecraft:poisonous_potato",count:1,components:{"minecraft:item_model":"weeb:muramasa_sheathed"}}}
ride @n[distance=..1,type=item_display,tag=newDisplay] mount @s
execute on passengers run tag @s remove newDisplay
function weeb:temple/rotate