execute unless entity @e[distance=..1,type=item_display,tag=weeb] run function weeb:temple/set_passenger

playsound minecraft:particle.soul_escape master @a ~ ~ ~ 3 0.9
execute if entity @s[tag=!rotated] run function weeb:temple/rotate
tag @s add thisInteract
execute on target run function weeb:temple/obtain_sword
tag @s remove thisInteract