execute at @s anchored eyes positioned ^ ^-0.3 ^10 anchored feet run summon armor_stand ~ ~ ~ {Tags:["weeb","weebBreaker"],Silent:1b,Marker:1b,Invisible:1b,Invisible:1b,equipment:{mainhand:{id:"minecraft:stick",count:1,components:{"minecraft:weapon":{disable_blocking_for_seconds:5}}}}}

damage @s 0.1 weeb:shield_break by @e[type=armor_stand,tag=weebBreaker,limit=1,sort=arbitrary]

kill @e[distance=..12,type=armor_stand,tag=weebBreaker,limit=1,sort=arbitrary]