scoreboard players add @s weeb.block 1

advancement revoke @s only weeb:rclick
advancement revoke @s only weeb:rclick_cd

scoreboard players set @s weeb.blockCD 2