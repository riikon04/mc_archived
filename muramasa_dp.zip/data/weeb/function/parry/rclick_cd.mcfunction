scoreboard players remove @s weeb.blockCD 1
execute if score @s weeb.blockCD matches 1.. run return run advancement revoke @s only weeb:rclick_cd
scoreboard players reset @s weeb.blockCD
scoreboard players reset @s weeb.block