scoreboard players reset #weebRange weeb.temp
scoreboard players operation @s weeb.id = #weebSearch weeb.id
scoreboard players operation @s weeb.objID = #weebSearch weeb.objID

function weeb:slash/rand/start
playsound minecraft:item.spear.lunge_1 master @a ~ ~ ~ 0.8 0.7
playsound minecraft:entity.player.attack.sweep master @a ~ ~ ~ 0.4 1.2

kill @s