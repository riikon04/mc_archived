scoreboard players remove #weebRange weeb.temp 1

execute positioned ~-1 ~-1 ~-1 positioned as @e[type=#weeb:targets,predicate=!weeb:match_id,dx=1,dy=1,dz=1,limit=1,sort=arbitrary] positioned ~ ~1 ~ summon marker run return run function weeb:parry/counter/setup_anchor
execute unless block ^ ^ ^1 #weeb:passable summon marker run return run function weeb:parry/counter/setup_anchor
execute if score #weebRange weeb.temp matches ..0 summon marker run return run function weeb:parry/counter/setup_anchor

execute if score #weebRange weeb.temp matches 1.. positioned ^ ^ ^1 run function weeb:parry/counter/raycast