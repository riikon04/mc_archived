function weeb:parry/disable_shield
scoreboard players add @s weeb.curseInvTime 40
advancement revoke @s only weeb:blocked
