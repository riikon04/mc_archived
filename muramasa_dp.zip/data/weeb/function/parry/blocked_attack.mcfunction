#adjust score requirement to change parry frames
execute if score @s weeb.block matches 6.. run return run function weeb:parry/blocked

#parry
#tellraw @p {"score":{"name":"@s","objective":"weeb.block"},"color":"yellow"}
playsound minecraft:block.anvil.place master @a ~ ~ ~ 1 1.4
playsound minecraft:block.bell.use master @a ~ ~ ~ 1 2
execute at @s anchored eyes positioned ^ ^-0.2 ^1 anchored feet run function weeb:parry/particles

scoreboard players add #objID weeb.objID 1
scoreboard players operation #weebSearch weeb.id = @s weeb.id
scoreboard players operation #weebSearch weeb.objID = #objID weeb.objID
scoreboard players set #weebRange weeb.temp 8
execute at @s anchored eyes positioned ^ ^ ^ anchored feet run function weeb:parry/counter/raycast

advancement revoke @s only weeb:blocked