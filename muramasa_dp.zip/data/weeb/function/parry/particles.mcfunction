particle crit ~ ~ ~ 0 0 0 1 10

particle minecraft:crit ^ ^ ^ ^700000.00000 ^0.00000 ^0 0.000001 0 force
particle minecraft:crit ^ ^ ^ ^646715.67276 ^267878.40266 ^0 0.000001 0 force
particle minecraft:crit ^ ^ ^ ^494974.74683 ^494974.74683 ^0 0.000001 0 force
particle minecraft:crit ^ ^ ^ ^267878.40266 ^646715.67276 ^0 0.000001 0 force
particle minecraft:crit ^ ^ ^ ^0.00000 ^700000.00000 ^0 0.000001 0 force
particle minecraft:crit ^ ^ ^ ^-267878.40266 ^646715.67276 ^0 0.000001 0 force
particle minecraft:crit ^ ^ ^ ^-494974.74683 ^494974.74683 ^0 0.000001 0 force
particle minecraft:crit ^ ^ ^ ^-646715.67276 ^267878.40266 ^0 0.000001 0 force
particle minecraft:crit ^ ^ ^ ^-700000.00000 ^0.00000 ^0 0.000001 0 force
particle minecraft:crit ^ ^ ^ ^-646715.67276 ^-267878.40266 ^0 0.000001 0 force
particle minecraft:crit ^ ^ ^ ^-494974.74683 ^-494974.74683 ^0 0.000001 0 force
particle minecraft:crit ^ ^ ^ ^-267878.40266 ^-646715.67276 ^0 0.000001 0 force
particle minecraft:crit ^ ^ ^ ^-0.00000 ^-700000.00000 ^0 0.000001 0 force
particle minecraft:crit ^ ^ ^ ^267878.40266 ^-646715.67276 ^0 0.000001 0 force
particle minecraft:crit ^ ^ ^ ^494974.74683 ^-494974.74683 ^0 0.000001 0 force
particle minecraft:crit ^ ^ ^ ^646715.67276 ^-267878.40266 ^0 0.000001 0 force
