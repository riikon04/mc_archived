scoreboard players operation #weebSearch weeb.objID = @s weeb.objID
kill @e[type=marker,tag=slashMark,predicate=weeb:match_obj]
kill @s