scoreboard players operation @s weeb.objID = #weebSearch weeb.objID
scoreboard players operation @s weeb.id = #weebSearch weeb.id
data merge entity @s {Tags:["weeb","slash"],brightness:{sky:15,block:15},item:{id:"minecraft:white_dye",count:1,components:{"minecraft:item_model":"weeb:slash"}},shadow_radius:0f,shadow_strength:0f}
rotate @s facing entity @n[type=marker,tag=slashEndMark,predicate=weeb:match_obj]
execute if entity @n[type=marker,tag=slashEndMark,tag=flurryAnchor,predicate=weeb:match_obj] run function weeb:slash/rand/adjust_pitch
schedule function weeb:slash/loop 1t append