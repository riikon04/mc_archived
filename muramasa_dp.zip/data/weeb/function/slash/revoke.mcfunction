advancement revoke @s only weeb:slash_tick
scoreboard players reset @s weeb.slashTime