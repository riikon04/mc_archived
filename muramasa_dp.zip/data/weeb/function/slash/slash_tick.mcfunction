advancement revoke @s only weeb:slash_tick

scoreboard players remove @s weeb.slashTime 1
execute if score @s weeb.slashTime matches ..0 run function weeb:slash/end_ray

execute if score @s weeb.slashTime matches ..0 run function weeb:slash/revoke