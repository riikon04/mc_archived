scoreboard players operation #weebSearch weeb.objID = @s weeb.objID
scoreboard players operation #weebSearch weeb.id = @s weeb.id

execute if entity @e[distance=..3.5,type=marker,tag=slashEndMark,predicate=weeb:match_obj] run return run function weeb:slash/clear

playsound minecraft:item.spear.lunge_1 master @a ~ ~ ~ 0.7 0.8
playsound minecraft:entity.player.attack.sweep master @a ~ ~ ~ 0.4 1.2
execute summon item_display run function weeb:slash/setup_slash
kill @e[type=marker,tag=slashMark,predicate=weeb:match_obj]