scoreboard players set #weebRange weeb.temp 24
execute anchored eyes positioned ^ ^ ^ anchored feet run function weeb:slash/raycast1