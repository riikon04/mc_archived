scoreboard players add @s weeb.slashTime 1

scoreboard players operation #weebSearch weeb.id = @s weeb.id
tag @p[predicate=weeb:match_id] add thisPlayer
execute positioned ^ ^ ^ run function weeb:slash/hitbox
execute positioned ^ ^ ^1 run function weeb:slash/hitbox
execute positioned ^ ^ ^2 run function weeb:slash/hitbox
execute positioned ^ ^ ^3 run function weeb:slash/hitbox
execute positioned ^ ^ ^4 run function weeb:slash/hitbox
execute positioned ^ ^ ^5 run function weeb:slash/hitbox
execute positioned ^ ^ ^-1 run function weeb:slash/hitbox
execute positioned ^ ^ ^-2 run function weeb:slash/hitbox
execute positioned ^ ^ ^-3 run function weeb:slash/hitbox
tag @p[predicate=weeb:match_id] remove thisPlayer

execute if score @s weeb.slashTime matches 2 run function weeb:slash/transform
execute if score @s weeb.slashTime matches 5 run function weeb:slash/transform1

execute unless score @s weeb.slashTime matches 12.. run tp @s ^ ^ ^0.5

execute if score @s weeb.slashTime matches 12.. run function weeb:slash/clear

schedule function weeb:slash/loop 1t append