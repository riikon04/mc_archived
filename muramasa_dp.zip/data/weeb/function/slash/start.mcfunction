scoreboard players operation #weebSearch weeb.id = @s weeb.id

execute if score @s weeb.slashTime matches 1.. run return fail

scoreboard players set #weebRange weeb.temp 24
execute anchored eyes positioned ^ ^ ^ anchored feet run function weeb:slash/raycast

advancement revoke @s only weeb:slash/slash_tick
scoreboard players set @s weeb.slashTime 4