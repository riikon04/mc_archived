scoreboard players operation @s weeb.id = #weebSearch weeb.id
scoreboard players operation @s weeb.objID = #objID weeb.objID

tag @s add weeb
tag @s add slashMark
tag @s add slashEndMark