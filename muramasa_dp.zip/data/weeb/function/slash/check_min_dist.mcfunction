scoreboard players operation #weebSearch weeb.objID = @s weeb.objID
tp @s ~ ~ ~
execute as @e[type=marker,tag=slashStartMark,predicate=weeb:match_obj,limit=1,sort=arbitrary] at @s run function weeb:slash/summon