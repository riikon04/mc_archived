scoreboard players operation #weebSearch weeb.objID = @s weeb.objID
scoreboard players operation #weebSearch weeb.id = @s weeb.id

$execute positioned ^$(x) ^$(y) ^$(z) summon item_display run function weeb:slash/setup_slash