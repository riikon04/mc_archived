execute store result score #pitch weeb.temp run data get entity @s Rotation[1] 1
execute store result score #temp weeb.temp run random value 0..12
execute store result score #sign weeb.temp run random value 0..1
execute if score #sign weeb.temp matches 1 run scoreboard players operation #temp weeb.temp *= #-1 weeb.const
scoreboard players operation #pitch weeb.temp += #temp weeb.temp
execute store result entity @s Rotation[1] float 1 run scoreboard players get #pitch weeb.temp