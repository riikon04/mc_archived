execute store result score #x weeb.temp run random value 3..6
execute store result score #y weeb.temp run random value 3..6
execute store result score #z weeb.temp run random value 3..6

execute store result score #sign weeb.temp run random value 0..1
execute if score #sign weeb.temp matches 1 run scoreboard players operation #x weeb.temp *= #-1 weeb.const

execute store result score #sign weeb.temp run random value 0..1
execute if score #sign weeb.temp matches 1 run scoreboard players operation #y weeb.temp *= #-1 weeb.const

execute store result score #sign weeb.temp run random value 0..1
execute if score #sign weeb.temp matches 1 run scoreboard players operation #z weeb.temp *= #-1 weeb.const

execute store result storage weeb:data x int 1 run scoreboard players get #x weeb.temp
execute store result storage weeb:data y int 1 run scoreboard players get #y weeb.temp
execute store result storage weeb:data z int 1 run scoreboard players get #z weeb.temp

tag @s add slashEndMark
function weeb:slash/rand/summon with storage weeb:data
tag @s remove slashEndMark