scoreboard players remove #weebRange weeb.temp 1

execute if score #weebRange weeb.temp matches ..0 run return run function weeb:slash/set_start
execute unless block ^ ^ ^0.5 #weeb:passable run return run function weeb:slash/set_start
execute positioned ~-0.5 ~-0.5 ~-0.5 if entity @e[type=#weeb:targets,predicate=!weeb:match_id,dx=0,dy=0,dz=0] positioned ~0.5 ~0.5 ~0.5 run function weeb:slash/set_start


execute if score #weebRange weeb.temp matches 1.. positioned ^ ^ ^0.25 run function weeb:slash/raycast