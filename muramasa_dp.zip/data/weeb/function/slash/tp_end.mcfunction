scoreboard players reset #weebRange weeb.temp
scoreboard players operation #weebSearch weeb.id = @s weeb.id
execute as @e[type=marker,tag=slashEndMark,predicate=weeb:match_id,limit=1,sort=arbitrary] run function weeb:slash/check_min_dist