scoreboard players reset #weebRange weeb.temp
scoreboard players operation #weebSearch weeb.id = @s weeb.id
scoreboard players add #objID weeb.objID 1
execute summon marker run function weeb:slash/setup_start_mark
execute summon marker run function weeb:slash/setup_end_mark
