scoreboard players add #weebID weeb.id 1
scoreboard players add @s weeb.id 0
scoreboard players operation @s weeb.id = #weebID weeb.id
tag @s add hasWeebID