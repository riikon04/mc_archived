## Pack initialization

#bool init
function hfd-sat:system/reload

scoreboard objectives add hfd.sat_apple_rng dummy "sat_ang"
scoreboard objectives add hfd.sat_direction_rng dummy "sat_dng"