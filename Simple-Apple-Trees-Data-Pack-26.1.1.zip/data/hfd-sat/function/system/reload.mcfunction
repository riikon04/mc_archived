#Reload datapack message
tellraw @a [{"text":"happyfied's Simple Apple Trees datapack loaded successfully!","color":"dark_green"}]