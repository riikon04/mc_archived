# Runs every game tick
# Updated to 1.20.5 and higher with MCStacker
# Updated to 1.21.4 and higher with a lot of pain
# Updated to 1.21.5 and higher with again MCStacker thank you pyro stunts i love you with my whole heart

# placing leaves
execute as @e[type=minecraft:item_frame,tag=sat_block] at @s run function hfd-sat:leaf_place_itemframe

# destroying leaves
execute as @e[type=minecraft:item_display,tag=sat_apples] at @s unless block ~ ~ ~ oak_leaves run function hfd-sat:apples_auto_destroy

# water scanner (this armor stand is built into the tree structures and detects if a tree generates on water, if so then removes the tree and itself)
execute as @e[name=hfd.sat_scanner] at @s if block ~1 ~ ~ water if block ~-1 ~ ~ water if block ~ ~ ~1 water if block ~ ~ ~-1 water run tag @s add on_water
execute as @e[name=hfd.sat_scanner,tag=on_water,tag=!running] at @s run function hfd-sat:scanner_sequence
kill @e[name=hfd.sat_scanner,tag=!on_water]