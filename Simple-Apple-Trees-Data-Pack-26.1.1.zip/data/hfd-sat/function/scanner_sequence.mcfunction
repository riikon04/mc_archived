# scanner removes the tree, and then itself

tag @s add running
setblock ~ ~ ~ air
fill ~ ~ ~ ~ ~10 ~ air replace oak_log
kill @e[type=minecraft:item_display,tag=sat_apples,distance=..8]
fill ~-3 ~0 ~-3 ~3 ~7 ~3 air replace minecraft:oak_leaves
kill @s