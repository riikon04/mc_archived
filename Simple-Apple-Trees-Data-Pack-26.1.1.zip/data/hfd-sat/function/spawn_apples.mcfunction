execute store result score sat_ang hfd.sat_apple_rng run random value 2..5
execute store result score sat_ang hfd.sat_direction_rng run random value 1..8

# 2 apples
execute if score sat_ang hfd.sat_apple_rng matches 2 if score sat_ang hfd.sat_direction_rng matches 1 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:2},Motion:[0.0,0.15,0.1]}
execute if score sat_ang hfd.sat_apple_rng matches 2 if score sat_ang hfd.sat_direction_rng matches 2 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:2},Motion:[0.1,0.15,0.1]}
execute if score sat_ang hfd.sat_apple_rng matches 2 if score sat_ang hfd.sat_direction_rng matches 3 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:2},Motion:[0.1,0.15,0.0]}
execute if score sat_ang hfd.sat_apple_rng matches 2 if score sat_ang hfd.sat_direction_rng matches 4 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:2},Motion:[0.1,0.15,-0.1]}
execute if score sat_ang hfd.sat_apple_rng matches 2 if score sat_ang hfd.sat_direction_rng matches 5 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:2},Motion:[0.0,0.15,-0.1]}
execute if score sat_ang hfd.sat_apple_rng matches 2 if score sat_ang hfd.sat_direction_rng matches 6 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:2},Motion:[-0.1,0.15,-0.1]}
execute if score sat_ang hfd.sat_apple_rng matches 2 if score sat_ang hfd.sat_direction_rng matches 7 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:2},Motion:[-0.1,0.15,0.0]}
execute if score sat_ang hfd.sat_apple_rng matches 2 if score sat_ang hfd.sat_direction_rng matches 8 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:2},Motion:[-0.1,0.15,0.1]}

# 3 apples
execute if score sat_ang hfd.sat_apple_rng matches 3 if score sat_ang hfd.sat_direction_rng matches 1 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:3},Motion:[0.0,0.15,0.1]}
execute if score sat_ang hfd.sat_apple_rng matches 3 if score sat_ang hfd.sat_direction_rng matches 2 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:3},Motion:[0.1,0.15,0.1]}
execute if score sat_ang hfd.sat_apple_rng matches 3 if score sat_ang hfd.sat_direction_rng matches 3 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:3},Motion:[0.1,0.15,0.0]}
execute if score sat_ang hfd.sat_apple_rng matches 3 if score sat_ang hfd.sat_direction_rng matches 4 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:3},Motion:[0.1,0.15,-0.1]}
execute if score sat_ang hfd.sat_apple_rng matches 3 if score sat_ang hfd.sat_direction_rng matches 5 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:3},Motion:[0.0,0.15,-0.1]}
execute if score sat_ang hfd.sat_apple_rng matches 3 if score sat_ang hfd.sat_direction_rng matches 6 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:3},Motion:[-0.1,0.15,-0.1]}
execute if score sat_ang hfd.sat_apple_rng matches 3 if score sat_ang hfd.sat_direction_rng matches 7 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:3},Motion:[-0.1,0.15,0.0]}
execute if score sat_ang hfd.sat_apple_rng matches 3 if score sat_ang hfd.sat_direction_rng matches 8 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:3},Motion:[-0.1,0.15,0.1]}

# 4 apples
execute if score sat_ang hfd.sat_apple_rng matches 4 if score sat_ang hfd.sat_direction_rng matches 1 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:4},Motion:[0.0,0.15,0.1]}
execute if score sat_ang hfd.sat_apple_rng matches 4 if score sat_ang hfd.sat_direction_rng matches 2 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:4},Motion:[0.1,0.15,0.1]}
execute if score sat_ang hfd.sat_apple_rng matches 4 if score sat_ang hfd.sat_direction_rng matches 3 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:4},Motion:[0.1,0.15,0.0]}
execute if score sat_ang hfd.sat_apple_rng matches 4 if score sat_ang hfd.sat_direction_rng matches 4 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:4},Motion:[0.1,0.15,-0.1]}
execute if score sat_ang hfd.sat_apple_rng matches 4 if score sat_ang hfd.sat_direction_rng matches 5 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:4},Motion:[0.0,0.15,-0.1]}
execute if score sat_ang hfd.sat_apple_rng matches 4 if score sat_ang hfd.sat_direction_rng matches 6 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:4},Motion:[-0.1,0.15,-0.1]}
execute if score sat_ang hfd.sat_apple_rng matches 4 if score sat_ang hfd.sat_direction_rng matches 7 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:4},Motion:[-0.1,0.15,0.0]}
execute if score sat_ang hfd.sat_apple_rng matches 4 if score sat_ang hfd.sat_direction_rng matches 8 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:4},Motion:[-0.1,0.15,0.1]}

# 5 apples
execute if score sat_ang hfd.sat_apple_rng matches 5 if score sat_ang hfd.sat_direction_rng matches 1 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:5},Motion:[0.0,0.15,0.1]}
execute if score sat_ang hfd.sat_apple_rng matches 5 if score sat_ang hfd.sat_direction_rng matches 2 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:5},Motion:[0.1,0.15,0.1]}
execute if score sat_ang hfd.sat_apple_rng matches 5 if score sat_ang hfd.sat_direction_rng matches 3 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:5},Motion:[0.1,0.15,0.0]}
execute if score sat_ang hfd.sat_apple_rng matches 5 if score sat_ang hfd.sat_direction_rng matches 4 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:5},Motion:[0.1,0.15,-0.1]}
execute if score sat_ang hfd.sat_apple_rng matches 5 if score sat_ang hfd.sat_direction_rng matches 5 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:5},Motion:[0.0,0.15,-0.1]}
execute if score sat_ang hfd.sat_apple_rng matches 5 if score sat_ang hfd.sat_direction_rng matches 6 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:5},Motion:[-0.1,0.15,-0.1]}
execute if score sat_ang hfd.sat_apple_rng matches 5 if score sat_ang hfd.sat_direction_rng matches 7 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:5},Motion:[-0.1,0.15,0.0]}
execute if score sat_ang hfd.sat_apple_rng matches 5 if score sat_ang hfd.sat_direction_rng matches 8 run summon item ~ ~-0.2 ~ {Item:{id:"apple",count:5},Motion:[-0.1,0.15,0.1]}

playsound minecraft:entity.item.pickup block @a ~ ~-0.2 ~ 0.5