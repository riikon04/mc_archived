setblock ~ ~ ~ minecraft:oak_leaves[persistent=true] destroy
playsound minecraft:block.grass.place block @a ~ ~ ~ 1 0.8
execute align xyz run summon item_display ~.5 ~.5 ~.5 {Tags:["sat_block","sat_apples"],transformation:[1.01f,0f,0f,0f,0f,1.01f,0f,0f,0f,0f,1.01f,0f,0f,0f,0f,1f],item:{id:"minecraft:azalea_leaves",count:1,components:{"minecraft:item_model":"hfd.sat:apples_bridge"}}}
kill @s