execute as @e[type=minecraft:zombified_piglin,tag=fkbm.zombified_piglin.explosive,tag=fkbm.zombified_piglin.explode_point] at @s run function fkbm:systems/mobs/loop/skill/zombified_piglin/explode
