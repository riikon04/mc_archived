execute \
    unless score $mcs_weather mcs_weather.uninstall_mode matches 1 \
    summon marker \
    run function \
        mcs_weather:data/flood
execute \
    if score $mcs_weather mcs_weather.uninstall_mode matches 1 \
    run function \
        mcs_weather:code/uninstall/text2