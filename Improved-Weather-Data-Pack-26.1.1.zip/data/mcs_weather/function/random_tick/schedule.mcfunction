execute \
    as @e[type=marker,\
        scores={mcs_weather.entity=3}] at @s \
    run function \
        mcs_weather:random_tick/apply2