$execute \
    store result score @s mcs_weather.tick_location_x \
    run random \
        value $(distance2)..$(distance)
$execute \
    store result score @s mcs_weather.tick_location_z \
    run random \
        value $(distance2)..$(distance)
execute \
    store result score @s mcs_weather.tick_location_x2 \
    run data \
        get entity @p Pos[0]
execute \
    store result score @s mcs_weather.tick_location_z2 \
    run data \
        get entity @p Pos[2]
scoreboard \
    players operation \
    @s mcs_weather.tick_location_x \
    += \
    @s mcs_weather.tick_location_x2
scoreboard \
    players operation \
    @s mcs_weather.tick_location_z \
    += \
    @s mcs_weather.tick_location_z2
execute \
    store result score @s mcs_weather.tick_location_x3 \
    run data \
        get entity @s Pos[0]
execute \
    store result score @s mcs_weather.tick_location_z3 \
    run data \
        get entity @s Pos[2]
scoreboard \
    players operation \
    @s mcs_weather.tick_location_x3 \
    -= \
    @s mcs_weather.tick_location_x2
scoreboard \
    players operation \
    @s mcs_weather.tick_location_z3 \
    -= \
    @s mcs_weather.tick_location_z2
execute \
    store result entity @s data.tick_pos_x int 1 \
    run scoreboard \
        players get @s mcs_weather.tick_location_x
execute \
    store result entity @s data.tick_pos_z int 1 \
    run scoreboard \
        players get @s mcs_weather.tick_location_z
function \
    mcs_weather:random_tick/apply \
    with entity @s data