$tp \
    @s $(tick_pos_x) ~ $(tick_pos_z)