execute \
    positioned over world_surface \
    run tp \
        @s ~ ~ ~
execute \
    if predicate mcs_weather:weather/clear \
    run function \
        mcs_weather:weather/clear
execute \
    if predicate mcs_weather:weather/rain \
    run function \
        mcs_weather:weather/rain
execute \
    if predicate mcs_weather:weather/thunder \
    run function \
        mcs_weather:weather/thunder
execute \
    unless dimension overworld \
    run kill \
        @s