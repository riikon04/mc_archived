data \
    modify entity @s CustomName set value '"Tornado Air Marker"'
data \
    modify entity @s Silent set value 1b
data \
    modify entity @s Invisible set value 1b
data \
    modify entity @s Marker set value 1b
scoreboard \
    players set @s mcs_weather.entity 5
data \
    modify entity @s data set value {mcs_weather:entity}