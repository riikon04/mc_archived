data \
    modify entity @s CustomName set value '"Sand Tornado Marker"'
execute \
    store result score @s mcs_weather.random_number \
    run random \
        value 1..4
scoreboard \
    players set @s mcs_weather.entity 1
data \
    modify entity @s data set value {mcs_weather:entity}