data \
    modify entity @s CustomName set value '"Savanna Fire Marker"'
scoreboard \
    players set @s mcs_weather.entity 2
data \
    modify entity @s data set value {mcs_weather:entity}