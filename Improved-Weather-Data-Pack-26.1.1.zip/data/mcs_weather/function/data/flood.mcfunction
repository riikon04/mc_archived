data \
    modify entity @s CustomName set value '"Flood Marker"'
scoreboard \
    players set @s mcs_weather.entity 4
data \
    modify entity @s data set value {mcs_weather:entity}