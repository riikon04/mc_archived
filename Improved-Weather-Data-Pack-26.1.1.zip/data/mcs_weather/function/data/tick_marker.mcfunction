data \
    modify entity @s CustomName set value '"Tick Marker"'
scoreboard \
    players set @s mcs_weather.entity 3
data \
    modify entity @s data set value {mcs_weather:entity}