$execute \
    store result score @s mcs_weather_random_tick_count \
    if entity @e[type=marker,\
        scores={mcs_weather.entity=3,\
        mcs_weather.tick_location_x3=$(distance2)..$(distance),\
        mcs_weather.tick_location_z3=$(distance2)..$(distance)}]
$execute \
    unless score @s mcs_weather_random_tick_count matches $(count).. \
    positioned ~ -100 ~ \
    summon marker \
    run function \
        mcs_weather:data/tick_marker
$execute \
    if score @s mcs_weather_random_tick_count matches $(count2).. \
    run kill \
        @e[type=marker,\
            scores={mcs_weather.entity=3},\
            limit=1,\
            sort=nearest]