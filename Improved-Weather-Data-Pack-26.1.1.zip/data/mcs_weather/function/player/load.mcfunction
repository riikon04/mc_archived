advancement \
    revoke @s only mcs_weather:player/1s
function \
    mcs_weather:player/1s \
    with storage mcs_weather:weather_tick