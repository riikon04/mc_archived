fill \
    ~2 ~-1 ~2 ~-2 ~-1 ~-2 \
    soul_campfire[lit=false,\
        facing=east] replace soul_campfire[lit=true,\
            facing=east]
fill \
    ~2 ~-1 ~2 ~-2 ~-1 ~-2 \
    soul_campfire[lit=false,\
        facing=west] replace soul_campfire[lit=true,\
            facing=west]
fill \
    ~2 ~-1 ~2 ~-2 ~-1 ~-2 \
    soul_campfire[lit=false,\
        facing=north] replace soul_campfire[lit=true,\
            facing=north]
fill \
    ~2 ~-1 ~2 ~-2 ~-1 ~-2 \
    soul_campfire[lit=false,\
        facing=south] replace soul_campfire[lit=true,\
            facing=south]