execute \
    if block ~ ~-1 ~ campfire \
    run function \
        mcs_weather:blocks/campfire/thunder/campfire
execute \
    if predicate mcs_weather:chance/0.5 \
    if block ~ ~-1 ~ soul_campfire \
    run function \
        mcs_weather:blocks/campfire/thunder/soul_campfire
particle \
    cloud ~ ~1 ~ 0.5 0.5 0.5 0.01 16 force
execute \
    if entity @p[distance=..16] \
    run playsound \
        block.fire.extinguish block @a[distance=..16] ~ ~ ~ 1 1