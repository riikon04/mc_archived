fill \
    ~2 ~-1 ~2 ~-2 ~-1 ~-2 \
    campfire[lit=false,\
        facing=east] replace campfire[lit=true,\
            facing=east]
fill \
    ~2 ~-1 ~2 ~-2 ~-1 ~-2 \
    campfire[lit=false,\
        facing=west] replace campfire[lit=true,\
            facing=west]
fill \
    ~2 ~-1 ~2 ~-2 ~-1 ~-2 \
    campfire[lit=false,\
        facing=north] replace campfire[lit=true,\
            facing=north]
fill \
    ~2 ~-1 ~2 ~-2 ~-1 ~-2 \
    campfire[lit=false,\
        facing=south] replace campfire[lit=true,\
            facing=south]