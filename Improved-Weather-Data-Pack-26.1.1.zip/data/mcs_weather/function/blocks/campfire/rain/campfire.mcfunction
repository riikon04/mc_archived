fill \
    ~1 ~-1 ~1 ~-1 ~-1 ~-1 \
    campfire[lit=false,\
        facing=east] replace campfire[lit=true,\
            facing=east]
fill \
    ~1 ~-1 ~1 ~-1 ~-1 ~-1 \
    campfire[lit=false,\
        facing=west] replace campfire[lit=true,\
            facing=west]
fill \
    ~1 ~-1 ~1 ~-1 ~-1 ~-1 \
    campfire[lit=false,\
        facing=north] replace campfire[lit=true,\
            facing=north]
fill \
    ~1 ~-1 ~1 ~-1 ~-1 ~-1 \
    campfire[lit=false,\
        facing=south] replace campfire[lit=true,\
            facing=south]