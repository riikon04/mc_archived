execute \
    if score @s mcs_weather.entity matches 3 \
    run function \
        mcs_weather:random_tick/global \
        with storage mcs_weather:weather_tick
execute \
    if score @s mcs_weather.entity matches 2 \
    if entity @p[distance=..128] \
    run function \
        mcs_weather:biomes/savanna/on_fire/global
execute \
    if score @s mcs_weather.entity matches 4 \
    if entity @p[distance=..128] \
    run function \
        mcs_weather:biomes/wet/water/global