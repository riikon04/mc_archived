scoreboard \
    players set $mcs_weather mcs_weather.uninstall_mode 1
reload