scoreboard \
    players reset $mcs_weather mcs_weather.uninstall_mode
tellraw \
    @s {"text":""}
tellraw \
    @s [{"text":"The uninstall process has been stopped! reloading...",\
        "color":"green"}]
reload