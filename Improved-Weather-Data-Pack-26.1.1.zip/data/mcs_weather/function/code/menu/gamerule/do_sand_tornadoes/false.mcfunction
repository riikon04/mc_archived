scoreboard \
    players set $mcs_weather do_sand_tornadoes 0
function \
    mcs_weather:code/menu/gamerule/start