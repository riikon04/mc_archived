scoreboard \
    players set $mcs_weather do_sand_tornadoes 1
function \
    mcs_weather:code/menu/gamerule/start