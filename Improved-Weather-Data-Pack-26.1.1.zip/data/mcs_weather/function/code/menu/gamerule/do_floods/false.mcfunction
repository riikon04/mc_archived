scoreboard \
    players set $mcs_weather do_floods 0
function \
    mcs_weather:code/menu/gamerule/start