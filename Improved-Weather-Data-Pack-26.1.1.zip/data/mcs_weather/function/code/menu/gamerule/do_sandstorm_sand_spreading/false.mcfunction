scoreboard \
    players set $mcs_weather do_sandstorm_sand_spreading 0
function \
    mcs_weather:code/menu/gamerule/start