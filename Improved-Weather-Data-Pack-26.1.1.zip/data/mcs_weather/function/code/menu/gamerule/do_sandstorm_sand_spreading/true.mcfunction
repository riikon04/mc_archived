scoreboard \
    players set $mcs_weather do_sandstorm_sand_spreading 1
function \
    mcs_weather:code/menu/gamerule/start