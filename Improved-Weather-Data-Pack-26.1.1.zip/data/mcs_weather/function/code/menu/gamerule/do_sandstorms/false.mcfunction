scoreboard \
    players set $mcs_weather do_sandstorms 0
function \
    mcs_weather:code/menu/gamerule/start