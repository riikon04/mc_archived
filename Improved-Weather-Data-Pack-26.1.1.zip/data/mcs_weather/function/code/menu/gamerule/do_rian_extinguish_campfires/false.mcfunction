scoreboard \
    players set $mcs_weather do_rian_extinguish_campfires 0
function \
    mcs_weather:code/menu/gamerule/start