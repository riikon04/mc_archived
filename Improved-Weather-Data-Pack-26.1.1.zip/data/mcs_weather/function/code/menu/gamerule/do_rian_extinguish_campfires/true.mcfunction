scoreboard \
    players set $mcs_weather do_rian_extinguish_campfires 1
function \
    mcs_weather:code/menu/gamerule/start