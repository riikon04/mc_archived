scoreboard \
    players set $mcs_weather do_waves 0
function \
    mcs_weather:code/menu/gamerule/start