scoreboard \
    players set $mcs_weather do_fire_flies_spawning 0
function \
    mcs_weather:code/menu/gamerule/start