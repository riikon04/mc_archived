scoreboard \
    players set $mcs_weather do_snow_melting 1
function \
    mcs_weather:code/menu/gamerule/start