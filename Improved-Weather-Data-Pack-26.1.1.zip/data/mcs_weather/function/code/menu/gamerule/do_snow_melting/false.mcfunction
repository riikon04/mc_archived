scoreboard \
    players set $mcs_weather do_snow_melting 0
function \
    mcs_weather:code/menu/gamerule/start