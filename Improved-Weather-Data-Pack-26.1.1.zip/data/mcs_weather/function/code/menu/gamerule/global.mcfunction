$dialog \
    show @s \
    {type:"multi_action",\
    title:{text:"Gamerules",\
    type:"text",\
    color:"yellow",\
    underlined:1b},\
    exit_action:{label:"Close",\
    width:200},\
    columns:3,\
    actions:[{label:"do_sand_tornadoes: $(do_sand_tornadoes)",\
    tooltip:"Enables sand tornadoes during thunder sandstorms in desert biomes",\
    width:250},\
    {label:"True",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_sand_tornadoes/true"}},\
    {label:"False",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_sand_tornadoes/false"}},\
    {label:"do_fog_in_wet_biomes: $(do_fog_in_wet_biomes)",\
    tooltip:"Enables fog in wet biomes (Swamp, Mangrove Swamp, Jungle, River, Ocean, Beach, Lush Caves and Dripstone Caves)",\
    width:250},\
    {label:"True",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_fog_in_wet_biomes/true"}},\
    {label:"False",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_fog_in_wet_biomes/false"}},\
    {label:"do_fire_flies_spawning: $(do_fire_flies_spawning)",\
    tooltip:"Enables fireflies to spawn (Swamp, Mangrove Swamp, River)",\
    width:250},\
    {label:"True",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_fire_flies_spawning/true"}},\
    {label:"False",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_fire_flies_spawning/false"}},\
    {label:"do_dynamic_snow_accumulation: $(do_dynamic_snow_accumulation)",\
    tooltip:"Makes snow accumulate in multiple layers, replace some plants, and apply freezing damage to entities",\
    width:250},\
    {label:"True",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_dynamic_snow_accumulation/true"}},\
    {label:"False",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_dynamic_snow_accumulation/false"}},\
    {label:"do_sandstorms: $(do_sandstorms)",\
    tooltip:"Enables sandstorms in desert biomes",\
    width:250},\
    {label:"True",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_sandstorms/true"}},\
    {label:"False",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_sandstorms/false"}},\
    {label:"do_dry_weather_in_savanna: $(do_dry_weather_in_savanna)",\
    tooltip:"Enables dry weather conditions in savannas, including fire and lightning storms",\
    width:250},\
    {label:"True",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_dry_weather_in_savanna/true"}},\
    {label:"False",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_dry_weather_in_savanna/false"}},\
    {label:"do_floods: $(do_floods)",\
    tooltip:"Enables floods in wet biomes",\
    width:250},\
    {label:"True",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_floods/true"}},\
    {label:"False",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_floods/false"}},\
    {label:"do_snow_melting: $(do_snow_melting)",\
    tooltip:"Enables snow layer melting; melting occurs five times slower in cold biomes",\
    width:250},\
    {label:"True",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_snow_melting/true"}},\
    {label:"False",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_snow_melting/false"}},\
    {label:"do_rian_extinguish_campfires: $(do_rian_extinguish_campfires)",\
    tooltip:"Allows rain to extinguish campfires",\
    width:250},\
    {label:"True",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_rian_extinguish_campfires/true"}},\
    {label:"False",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_rian_extinguish_campfires/false"}},\
    {label:"do_sandstorm_sand_spreading: $(do_sandstorm_sand_spreading)",\
    tooltip:"Makes sandstorms carry sand and spread it across the area",\
    width:250},\
    {label:"True",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_sandstorm_sand_spreading/true"}},\
    {label:"False",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_sandstorm_sand_spreading/false"}},\
    {label:"do_snow_persistence_in_cold_biomes: $(do_snow_persistence_in_cold_biomes)",\
    tooltip:"Prevents snow layers from melting completely in cold biomes",\
    width:250},\
    {label:"True",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_snow_persistence_in_cold_biomes/true"}},\
    {label:"False",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_snow_persistence_in_cold_biomes/false"}},\
    {label:"do_waves: $(do_waves)",\
    tooltip:"Enables ocean waves",\
    width:250},\
    {label:"True",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_waves/true"}},\
    {label:"False",\
    width:50,\
    action:{type:"minecraft:run_command",\
    command:"function mcs_weather:code/menu/gamerule/do_waves/false"}},\
    {label:"Back to Menu",\
    tooltip:"Back to the main menu of the Improved Weather modification!",\
    width:175,\
    action:{type:"show_dialog",\
    dialog:"mcs_weather:menu"}}]}