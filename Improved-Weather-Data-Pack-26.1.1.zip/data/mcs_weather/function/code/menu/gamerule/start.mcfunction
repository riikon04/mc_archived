execute \
    store result storage mcs_weather:menu/gamerules do_sand_tornadoes int 1 \
    run scoreboard \
        players get $mcs_weather do_sand_tornadoes
execute \
    store result storage mcs_weather:menu/gamerules do_fog_in_wet_biomes int 1 \
    run scoreboard \
        players get $mcs_weather do_fog_in_wet_biomes
execute \
    store result storage mcs_weather:menu/gamerules do_fire_flies_spawning int 1 \
    run scoreboard \
        players get $mcs_weather do_fire_flies_spawning
execute \
    store result storage mcs_weather:menu/gamerules do_dynamic_snow_accumulation int 1 \
    run scoreboard \
        players get $mcs_weather do_dynamic_snow_accumulation
execute \
    store result storage mcs_weather:menu/gamerules do_sandstorms int 1 \
    run scoreboard \
        players get $mcs_weather do_sandstorms
execute \
    store result storage mcs_weather:menu/gamerules do_dry_weather_in_savanna int 1 \
    run scoreboard \
        players get $mcs_weather do_dry_weather_in_savanna
execute \
    store result storage mcs_weather:menu/gamerules do_floods int 1 \
    run scoreboard \
        players get $mcs_weather do_floods
execute \
    store result storage mcs_weather:menu/gamerules do_snow_melting int 1 \
    run scoreboard \
        players get $mcs_weather do_snow_melting
execute \
    store result storage mcs_weather:menu/gamerules do_rian_extinguish_campfires int 1 \
    run scoreboard \
        players get $mcs_weather do_rian_extinguish_campfires
execute \
    store result storage mcs_weather:menu/gamerules do_sandstorm_sand_spreading int 1 \
    run scoreboard \
        players get $mcs_weather do_sandstorm_sand_spreading
execute \
    store result storage mcs_weather:menu/gamerules do_snow_persistence_in_cold_biomes int 1 \
    run scoreboard \
        players get $mcs_weather do_snow_persistence_in_cold_biomes
execute \
    store result storage mcs_weather:menu/gamerules do_waves int 1 \
    run scoreboard \
        players get $mcs_weather do_waves
function \
    mcs_weather:code/menu/gamerule/global \
    with storage mcs_weather:menu/gamerules