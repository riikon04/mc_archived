scoreboard \
    players set $mcs_weather do_dynamic_snow_accumulation 1
function \
    mcs_weather:code/menu/gamerule/start