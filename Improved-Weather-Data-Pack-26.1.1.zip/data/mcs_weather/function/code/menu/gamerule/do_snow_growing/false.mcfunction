scoreboard \
    players set $mcs_weather do_dynamic_snow_accumulation 0
function \
    mcs_weather:code/menu/gamerule/start