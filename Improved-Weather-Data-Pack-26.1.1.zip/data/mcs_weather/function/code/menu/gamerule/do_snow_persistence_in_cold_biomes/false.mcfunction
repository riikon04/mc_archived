scoreboard \
    players set $mcs_weather do_snow_persistence_in_cold_biomes 0
function \
    mcs_weather:code/menu/gamerule/start