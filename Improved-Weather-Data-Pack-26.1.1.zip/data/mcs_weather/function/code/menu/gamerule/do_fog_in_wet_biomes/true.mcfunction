scoreboard \
    players set $mcs_weather do_fog_in_wet_biomes 1
function \
    mcs_weather:code/menu/gamerule/start