scoreboard \
    players set $mcs_weather do_dry_weather_in_savanna 1
function \
    mcs_weather:code/menu/gamerule/start