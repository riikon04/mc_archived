scoreboard \
    players set $mcs_weather do_dry_weather_in_savanna 0
function \
    mcs_weather:code/menu/gamerule/start