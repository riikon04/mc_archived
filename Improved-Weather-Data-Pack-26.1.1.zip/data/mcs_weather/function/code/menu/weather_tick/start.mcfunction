execute \
    store result storage mcs_weather:weather_tick display int 0.0625 \
    run data \
        get storage mcs_weather:weather_tick distance
execute \
    store result storage mcs_weather:weather_tick count int 1 \
    run data \
        get storage mcs_weather:weather_tick count
function \
    mcs_weather:code/menu/weather_tick/global \
    with storage mcs_weather:weather_tick