$dialog \
    show @s \
    {type:"multi_action",\
    title:{text:"Weather Tick",\
    type:"text",\
    color:"yellow",\
    underlined:1},\
    exit_action:{label:"Close",\
    width:200},\
    columns:2,\
    actions:[{label:"Tick Spread Distance: $(display)",\
    width:250},\
    {label:"Set",\
    width:50,\
    action:{type:"minecraft:show_dialog",\
    dialog:"mcs_weather:weather_tick"}},\
    {label:"Tick Count: $(count)",\
    width:250},\
    {label:"Set",\
    width:50,\
    action:{type:"minecraft:show_dialog",\
    dialog:"mcs_weather:weather_tick2"}},\
    {label:"Back to Menu",\
    tooltip:"Back to the main menu of the Improved Weather modification!",\
    width:175,\
    action:{type:"show_dialog",\
    dialog:"mcs_weather:menu"}}]}