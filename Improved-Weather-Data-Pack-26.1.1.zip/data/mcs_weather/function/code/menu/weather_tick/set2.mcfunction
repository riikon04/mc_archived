$data \
    modify storage mcs_weather:weather_tick count set value $(count)
execute \
    store result score $mcs_weather mcs_weather.random_number \
    run data \
        get storage mcs_weather:weather_tick count
scoreboard \
    players set $mcs_weather mcs_weather.random_number2 1
scoreboard \
    players operation $mcs_weather mcs_weather.random_number \
    += $mcs_weather mcs_weather.random_number2
execute \
    store result storage mcs_weather:weather_tick count2 int 1 \
    run scoreboard \
        players get $mcs_weather mcs_weather.random_number
function \
    mcs_weather:code/menu/weather_tick/start