$data \
    modify storage mcs_weather:weather_tick display set value $(distance)
execute \
    store result storage mcs_weather:weather_tick distance int 16 \
    run data \
        get storage mcs_weather:weather_tick display
execute \
    store result storage mcs_weather:weather_tick distance2 int -1 \
    run data \
        get storage mcs_weather:weather_tick distance
function \
    mcs_weather:code/menu/weather_tick/start