scoreboard \
    players set $mcs_weather mcs_weather.update_26.1v1 1
tellraw \
    @a {"text":""}
tellraw \
    @a {"text":"Improved Weather modification has been updated to 26.1v1!",\
        "color":"green",\
        "bold":true}