execute \
    unless data storage mcs_weather:weather_tick count \
    run data \
        modify storage mcs_weather:weather_tick count set value 4
execute \
    unless data storage mcs_weather:weather_tick count2 \
    run data \
        modify storage mcs_weather:weather_tick count2 set value 5
execute \
    unless data storage mcs_weather:weather_tick distance \
    run data \
        modify storage mcs_weather:weather_tick distance set value 64
execute \
    unless data storage mcs_weather:weather_tick distance2 \
    run data \
        modify storage mcs_weather:weather_tick distance2 set value -64