scoreboard \
    objectives add mcs_weather.random_number dummy
scoreboard \
    objectives add mcs_weather.tick_location_x dummy
scoreboard \
    objectives add mcs_weather.tick_location_z dummy
scoreboard \
    objectives add mcs_weather.tick_location_x2 dummy
scoreboard \
    objectives add mcs_weather.tick_location_z2 dummy
scoreboard \
    objectives add mcs_weather.tick_location_x3 dummy
scoreboard \
    objectives add mcs_weather.tick_location_z3 dummy
scoreboard \
    objectives add mcs_weather_sandstorm dummy
scoreboard \
    objectives add mcs_weather_random_tick_count dummy
scoreboard \
    objectives add mcs_weather_sandstorm2 dummy
scoreboard \
    objectives add mcs_weather.random_number2 dummy
scoreboard \
    objectives add mcs_weather.random_number3 dummy
scoreboard \
    objectives add mcs_weather.weather_tick_count dummy
scoreboard \
    objectives add mcs_weather.weather_tick_distance dummy
scoreboard \
    objectives add mcs_weather.entity dummy
scoreboard \
    objectives add mcs_weather.tornado_marker_1t dummy
scoreboard \
    objectives add mcs_weather.tornado_grab_1t dummy