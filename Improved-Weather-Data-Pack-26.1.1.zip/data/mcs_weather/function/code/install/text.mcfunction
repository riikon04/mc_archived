tellraw \
    @a {"text":""}
tellraw \
    @a {"text":"Improved Weather modification has been installed!",\
        "color":"green",\
        "bold":true}
tellraw \
    @a {"text":"Developed By: MC Silver",\
        "color":"green",\
        "bold":true}
scoreboard \
    players set $mcs_weather mcs_weather.install_main 1