execute \
    unless score $mcs_weather mcs_weather.install_main matches 1 \
    run function \
        mcs_weather:code/install/text
function \
    mcs_weather:code/install/gamerules/add
function \
    mcs_weather:code/install/scoreboards
function \
    mcs_weather:code/install/data