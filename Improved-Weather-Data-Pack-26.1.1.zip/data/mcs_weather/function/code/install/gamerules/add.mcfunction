scoreboard \
    objectives add do_sand_tornadoes dummy
scoreboard \
    objectives add do_fog_in_wet_biomes dummy
scoreboard \
    objectives add do_fire_flies_spawning dummy
scoreboard \
    objectives add do_dynamic_snow_accumulation dummy
scoreboard \
    objectives add do_sandstorms dummy
scoreboard \
    objectives add do_dry_weather_in_savanna dummy
scoreboard \
    objectives add do_floods dummy
scoreboard \
    objectives add do_snow_melting dummy
scoreboard \
    objectives add do_rian_extinguish_campfires dummy
scoreboard \
    objectives add do_sandstorm_sand_spreading dummy
scoreboard \
    objectives add do_snow_persistence_in_cold_biomes dummy
scoreboard \
    objectives add do_waves dummy
function \
    mcs_weather:code/install/gamerules/set