execute \
    unless score $mcs_weather do_sand_tornadoes matches 0..1 \
    run scoreboard \
        players set $mcs_weather do_sand_tornadoes 1
execute \
    unless score $mcs_weather do_fog_in_wet_biomes matches 0..1 \
    run scoreboard \
        players set $mcs_weather do_fog_in_wet_biomes 1
execute \
    unless score $mcs_weather do_fire_flies_spawning matches 0..1 \
    run scoreboard \
        players set $mcs_weather do_fire_flies_spawning 1
execute \
    unless score $mcs_weather do_dynamic_snow_accumulation matches 0..1 \
    run scoreboard \
        players set $mcs_weather do_dynamic_snow_accumulation 1
execute \
    unless score $mcs_weather do_sandstorms matches 0..1 \
    run scoreboard \
        players set $mcs_weather do_sandstorms 1
execute \
    unless score $mcs_weather do_dry_weather_in_savanna matches 0..1 \
    run scoreboard \
        players set $mcs_weather do_dry_weather_in_savanna 1
execute \
    unless score $mcs_weather do_floods matches 0..1 \
    run scoreboard \
        players set $mcs_weather do_floods 1
execute \
    unless score $mcs_weather do_snow_melting matches 0..1 \
    run scoreboard \
        players set $mcs_weather do_snow_melting 1
execute \
    unless score $mcs_weather do_rian_extinguish_campfires matches 0..1 \
    run scoreboard \
        players set $mcs_weather do_rian_extinguish_campfires 1
execute \
    unless score $mcs_weather do_sandstorm_sand_spreading matches 0..1 \
    run scoreboard \
        players set $mcs_weather do_sandstorm_sand_spreading 1
execute \
    unless score $mcs_weather do_snow_persistence_in_cold_biomes matches 0..1 \
    run scoreboard \
        players set $mcs_weather do_snow_persistence_in_cold_biomes 1
execute \
    unless score $mcs_weather do_waves matches 0..1 \
    run scoreboard \
        players set $mcs_weather do_waves 1