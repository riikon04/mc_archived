execute \
    unless score $mcs_weather mcs_weather.uninstall_mode matches 1 \
    run schedule \
        function mcs_weather:code/loop/20s 20s
kill \
    @e[type=#mcs_weather:markers,\
        tag=mcs_weather.entity]