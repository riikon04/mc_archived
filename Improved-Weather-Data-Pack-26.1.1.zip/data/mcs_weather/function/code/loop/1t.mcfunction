execute \
    unless score $mcs_weather mcs_weather.uninstall_mode matches 1 \
    run schedule \
        function mcs_weather:code/loop/1t 1t
execute \
    if score $mcs_weather mcs_weather.tornado_marker_1t matches 1 \
    as @e[type=marker,\
        scores={mcs_weather.entity=1}] at @s \
    run execute \    
        if entity @p[distance=..128] at @s \
    run function \
        mcs_weather:weather/tornado/1t
execute \
    if score $mcs_weather mcs_weather.tornado_grab_1t matches 1 \
    as @e[type=armor_stand,\
        scores={mcs_weather.entity=5}] at @s \
    run execute \    
        if entity @p[distance=..128] at @s \
    run function \
        mcs_weather:weather/tornado/grab/global