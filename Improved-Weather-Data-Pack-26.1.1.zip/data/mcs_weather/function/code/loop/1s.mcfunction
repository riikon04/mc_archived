execute \
    unless score $mcs_weather mcs_weather.uninstall_mode matches 1 \
    run schedule \
        function mcs_weather:code/loop/1s 1s
execute \
    as @e[type=marker,\
        scores={mcs_weather.entity=2..4}] at @s \
    run function \
        mcs_weather:everything/global_marker
schedule \
    function mcs_weather:random_tick/schedule 1t
execute \
    store result score $mcs_weather mcs_weather.tornado_marker_1t \
    if entity @e[type=marker,\
        scores={mcs_weather.entity=1},\
        limit=1]
execute \
    store result score $mcs_weather mcs_weather.tornado_grab_1t \
    if entity @e[type=armor_stand,\
        scores={mcs_weather.entity=5},\
        limit=1]