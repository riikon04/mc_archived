tellraw \
    @a {"text":""}
tellraw \
    @a {"color":"red",\
        "text":"Improved Weather modification is in uninstall mode! \
        All modification functions are disabled and custom items/entities are deleted! \
        Once you have gotten rid of all the modified items/entities, \
        you can delete this modification!"}