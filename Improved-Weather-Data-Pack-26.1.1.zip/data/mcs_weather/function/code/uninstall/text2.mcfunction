tellraw \
    @s {"text":""}
tellraw \
    @s {"color":"red",\
        "text":"You cannot use this command, \
         the modification is in uninstall mode!"}