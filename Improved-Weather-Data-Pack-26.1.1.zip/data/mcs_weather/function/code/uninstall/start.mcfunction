function \
    mcs_weather:code/uninstall/text
scoreboard \
    objectives remove mcs_weather.install_main
scoreboard \
    objectives remove mcs_weather.update_26.1v1
scoreboard \
    objectives remove do_sand_tornadoes
scoreboard \
    objectives remove do_fog_in_wet_biomes
scoreboard \
    objectives remove do_fire_flies_spawning
scoreboard \
    objectives remove do_dynamic_snow_accumulation
scoreboard \
    objectives remove do_sandstorms
scoreboard \
    objectives remove do_dry_weather_in_savanna
scoreboard \
    objectives remove do_floods
scoreboard \
    objectives remove do_snow_melting
scoreboard \
    objectives remove do_rian_extinguish_campfires
scoreboard \
    objectives remove do_sandstorm_sand_spreading
scoreboard \
    objectives remove do_snow_persistence_in_cold_biomes
scoreboard \
    objectives remove do_waves
scoreboard \
    objectives remove mcs_weather.random_number
scoreboard \
    objectives remove mcs_weather.tick_location_x
scoreboard \
    objectives remove mcs_weather.tick_location_z
scoreboard \
    objectives remove mcs_weather.tick_location_x2
scoreboard \
    objectives remove mcs_weather.tick_location_z2
scoreboard \
    objectives remove mcs_weather.tick_location_x3
scoreboard \
    objectives remove mcs_weather.tick_location_z3
scoreboard \
    objectives remove mcs_weather_sandstorm
scoreboard \
    objectives remove mcs_weather_random_tick_count
scoreboard \
    objectives remove mcs_weather_sandstorm2
scoreboard \
    objectives remove mcs_weather.random_number2
scoreboard \
    objectives remove mcs_weather.random_number3
scoreboard \
    objectives remove mcs_weather.weather_tick_count
scoreboard \
    objectives remove mcs_weather.weather_tick_distance
scoreboard \
    objectives remove mcs_weather.entity
scoreboard \
    objectives remove mcs_weather.update_message
scoreboard \
    objectives remove mcs_weather.update_mode
function \
    mcs_weather:code/uninstall/1s