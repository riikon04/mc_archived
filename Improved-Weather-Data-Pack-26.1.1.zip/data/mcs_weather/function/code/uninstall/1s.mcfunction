execute \
    if score $mcs_weather mcs_weather.uninstall_mode matches 1 \
    run schedule \
        function mcs_weather:code/uninstall/1s 1s
execute \
    as @e[type=#mcs_weather:markers,\
        nbt={data:{mcs_weather:entity}}] at @s \
    run function \
        mcs_weather:code/uninstall/delete/entitites