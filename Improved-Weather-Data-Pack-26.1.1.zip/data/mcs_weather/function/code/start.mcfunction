function \
    mcs_weather:code/loop/1t
schedule \
    function mcs_weather:code/loop/1s 1s
function \
    mcs_weather:code/loop/20s
scoreboard \
    objectives add mcs_weather.install_main dummy
scoreboard \
    objectives add mcs_weather.update_26.1v1 dummy
schedule \
    function mcs_weather:code/install/main 3s
execute \
    unless score $mcs_weather mcs_weather.update_26.1v1 matches 1 \
    run schedule \
        function mcs_weather:code/update/load 3s
execute \
    if score $mcs_weather do_dynamic_snow_accumulation matches 1 \
    run gamerule \
        max_snow_accumulation_height 8
execute \
    if score $mcs_weather do_dynamic_snow_accumulation matches 0 \
    run gamerule \
        max_snow_accumulation_height 1