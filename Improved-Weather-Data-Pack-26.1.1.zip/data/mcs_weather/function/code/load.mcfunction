scoreboard \
    objectives add mcs_weather.uninstall_mode dummy
execute \
    unless score $mcs_weather mcs_weather.uninstall_mode matches 1 \
    run function \
        mcs_weather:code/start
execute \
    if score $mcs_weather mcs_weather.uninstall_mode matches 1 \
    run schedule \
        function mcs_weather:code/uninstall/start 3s