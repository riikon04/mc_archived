particle \
    firefly ~ ~6 ~ 16 4 16 1 16 force
execute \
    if entity @p[distance=..32] \
    run playsound \
        block.firefly_bush.idle ambient @a[distance=..32] ~ ~ ~ 2 0.1