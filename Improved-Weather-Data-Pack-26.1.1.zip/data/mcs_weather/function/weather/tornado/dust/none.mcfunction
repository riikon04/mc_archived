particle \
    cloud ~ ~8 ~ 2 8 2 0.01 8 force
particle \
    cloud ~ ~12 ~ 3 12 3 0.01 8 force
particle \
    cloud ~ ~16 ~ 4 16 4 0.01 8 force
particle \
    falling_dust{block_state:dirt} ~ ~16 ~ 4 16 4 1 8 force