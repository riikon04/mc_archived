particle \
    dust_color_transition{from_color:[0.906,0.894,0.733],\
        scale:4,\
        to_color:[0.855,0.812,0.639]} ~ ~8 ~ 2 8 2 1 2 force
particle \
    dust_color_transition{from_color:[0.906,0.894,0.733],\
        scale:4,\
        to_color:[0.855,0.812,0.639]} ~ ~12 ~ 3 12 3 1 2 force
particle \
    dust_color_transition{from_color:[0.906,0.894,0.733],\
        scale:4,\
        to_color:[0.855,0.812,0.639]} ~ ~16 ~ 4 16 4 1 2 force
particle \
    falling_dust{block_state:sand} ~ ~16 ~ 4 16 4 1 2 force
particle \
    dust_color_transition{from_color:[0.824,0.459,0.169],\
        scale:4,\
        to_color:[0.749,0.404,0.129]} ~ ~8 ~ 2 8 2 1 2 force
particle \
    dust_color_transition{from_color:[0.824,0.459,0.169],\
        scale:4,\
        to_color:[0.749,0.404,0.129]} ~ ~12 ~ 3 12 3 1 2 force
particle \
    dust_color_transition{from_color:[0.824,0.459,0.169],\
        scale:4,\
        to_color:[0.749,0.404,0.129]} ~ ~16 ~ 4 16 4 1 2 force
particle \
    falling_dust{block_state:red_sand} ~ ~16 ~ 4 16 4 1 2 force