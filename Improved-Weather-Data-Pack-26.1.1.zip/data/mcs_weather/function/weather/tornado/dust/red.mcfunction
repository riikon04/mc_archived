particle \
    dust_color_transition{from_color:[0.824,0.459,0.169],\
        scale:4,\
        to_color:[0.749,0.404,0.129]} ~ ~8 ~ 2 8 2 1 4 force
particle \
    dust_color_transition{from_color:[0.824,0.459,0.169],\
        scale:4,\
        to_color:[0.749,0.404,0.129]} ~ ~12 ~ 3 12 3 1 4 force
particle \
    dust_color_transition{from_color:[0.824,0.459,0.169],\
        scale:4,\
        to_color:[0.749,0.404,0.129]} ~ ~16 ~ 4 16 4 1 4 force
particle \
    falling_dust{block_state:red_sand} ~ ~16 ~ 4 16 4 1 4 force