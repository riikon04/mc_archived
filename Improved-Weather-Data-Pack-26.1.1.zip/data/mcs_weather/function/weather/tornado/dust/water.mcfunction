execute \
    if predicate mcs_weather:chance/0.1 \
    run fill \
        ~2 ~2 ~2 ~-2 ~ ~-2 water[level=15] keep
fill \
    ~4 ~-1 ~4 ~-4 ~-1 ~-4 air replace #mcs_weather:water_plants
particle \
    dust_color_transition{from_color:[0.247,0.463,0.894],\
        scale:4,\
        to_color:[0.090,0.529,0.831]} ~ ~8 ~ 2 8 2 1 4 force
particle \
    dust_color_transition{from_color:[0.247,0.463,0.894],\
        scale:4,\
        to_color:[0.090,0.529,0.831]} ~ ~12 ~ 3 12 3 1 4 force
particle \
    dust_color_transition{from_color:[0.247,0.463,0.894],\
        scale:4,\
        to_color:[0.090,0.529,0.831]} ~ ~16 ~ 4 16 4 1 4 force
particle \
    falling_water ~ ~16 ~ 4 16 4 1 4 force