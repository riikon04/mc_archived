execute \
    store result score @s mcs_weather.random_number2 \
    run random \
        value 1..8
execute \
    if score @s mcs_weather.random_number2 matches 1 \
    run tp \
        @s ~0.5 ~ ~
execute \
    if score @s mcs_weather.random_number2 matches 2 \
    run tp \
        @s ~-0.5 ~ ~
execute \
    if score @s mcs_weather.random_number2 matches 3 \
    run tp \
        @s ~ ~ ~0.5
execute \
    if score @s mcs_weather.random_number2 matches 4 \
    run tp \
        @s ~ ~ ~-0.5
execute \
    if score @s mcs_weather.random_number2 matches 5..8 \
    run tp \
        @s ~ ~0.5 ~
execute \
    unless block ~ ~ ~ #air \
    run kill \
        @s
execute \
    unless entity @e[type=marker,\
        scores={mcs_weather.entity=1},\
        distance=..24,\
        limit=1] \
    run kill \
        @s
execute \
    if entity @p[distance=..32] \
    run particle \
        cloud ~ ~1 ~ 0.5 0.5 0.5 0.01 1 normal
execute \
    if predicate mcs_weather:no_passanger \
    as @e[type=!#mcs_weather:ignore,\
        predicate=!mcs_weather:players/op,\
        distance=..8,\
        limit=1,\
        sort=nearest] \
    run ride \
        @s mount @e[type=armor_stand,\
            scores={mcs_weather.entity=5},\
            limit=1,\
            sort=nearest,\
            predicate=mcs_weather:no_passanger,\
            distance=..8]
execute \
    as @e[type=!#mcs_weather:immune_to_sandstorm,\
        predicate=!mcs_weather:nbt/villager/desert,\
        predicate=mcs_weather:location/can_see_sky,\
        predicate=!mcs_weather:players/op,\
        predicate=!mcs_weather:armor/leather_helmet/item,\
        distance=..2.3] \
    run function \
        mcs_weather:weather/sandstorm/effects/thunder