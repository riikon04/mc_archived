execute \
    if score @s mcs_weather_sandstorm matches 1.. \
    unless score @s mcs_weather_sandstorm2 matches 1.. \
    run function \
        mcs_weather:weather/tornado/dust/default
execute \
    unless score @s mcs_weather_sandstorm matches 1.. \
    if score @s mcs_weather_sandstorm2 matches 1.. \
    run function \
        mcs_weather:weather/tornado/dust/red
execute \
    if score @s mcs_weather_sandstorm matches 1.. \
    if score @s mcs_weather_sandstorm2 matches 1.. \
    run function \
        mcs_weather:weather/tornado/dust/mix
execute \
    unless score @s mcs_weather_sandstorm matches 1.. \
    unless score @s mcs_weather_sandstorm2 matches 1.. \
    run function \
        mcs_weather:weather/tornado/dust/none