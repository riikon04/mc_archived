playsound \
    entity.wither.break_block block @a[distance=..32] ~ ~ ~ 2 0.25
playsound \
    ambient.basalt_deltas.mood block @a[distance=..32] ~ ~ ~ 2 0.5
particle \
    dust_color_transition{from_color:[0.906,0.894,0.733],\
        scale:4,\
        to_color:[0.855,0.812,0.639]} ~ ~8 ~ 2 8 2 1 40 force
particle \
    dust_color_transition{from_color:[0.890,0.859,0.690],\
        scale:4,\
        to_color:[0.820,0.729,0.541]} ~ ~12 ~ 3 12 3 1 40 force
particle \
    dust_color_transition{from_color:[0.890,0.859,0.690],\
        scale:4,\
        to_color:[0.855,0.812,0.639]} ~ ~16 ~ 4 16 4 1 40 force
particle \
    falling_dust{block_state:sand} ~ ~16 ~ 4 16 4 1 40 force
particle \
    squid_ink ~ ~4 ~ 4 4 4 0 40 force
execute \
    as @e[type=!#mcs_weather:ignore,\
        type=!husk,\
        type=!breeze,\
        predicate=!mcs_weather:players/op,\
        distance=..8] at @s \
    run damage \
        @s 8 falling_block at ~ ~ ~
kill \
    @s