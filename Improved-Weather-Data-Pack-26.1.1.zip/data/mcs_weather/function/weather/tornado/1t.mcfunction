execute \
    unless block ~ ~-1 ~ water \
    run function \
        mcs_weather:weather/tornado/non_water
execute \
    if block ~ ~-1 ~ water \
    run function \
        mcs_weather:weather/tornado/dust/water
execute \
    if entity @p[distance=..64] \
    run function \
        mcs_weather:weather/tornado/sounds
execute \
    if predicate mcs_weather:chance/0.01 \
    store result score @s mcs_weather.random_number \
    run random \
        value 1..4
execute \
    if score @s mcs_weather.random_number matches 1 \
    run tp \
        @s ~0.2 ~ ~
execute \
    if score @s mcs_weather.random_number matches 2 \
    run tp \
        @s ~-0.2 ~ ~
execute if score @s mcs_weather.random_number matches 3 \
    run tp \
        @s ~ ~ ~0.2
execute \
    if score @s mcs_weather.random_number matches 4 \
    run tp \
        @s ~ ~ ~-0.2
execute \
    if predicate mcs_weather:chance/0.01 \
    positioned over world_surface \
    run tp \
        @s ~ ~ ~
execute \
    as @e[type=#mcs_weather:tornado_physics_projectile,\
        distance=..16] \
    run function \
        mcs_weather:weather/tornado/random_motions
execute \
    if predicate mcs_weather:chance/0.1 \
    summon armor_stand \
    run function \
        mcs_weather:data/tornado_grab
execute \
    if block ~ ~-1 ~ sand \
    run scoreboard \
        players add @s mcs_weather_sandstorm 20
execute \
    if block ~ ~-1 ~ red_sand \
    run scoreboard \
        players add @s mcs_weather_sandstorm2 20
execute \
    if score @s mcs_weather_sandstorm matches 1.. \
    if predicate mcs_weather:chance/0.5 \
    run scoreboard \
        players remove @s mcs_weather_sandstorm 1
execute \
    if predicate mcs_weather:chance/0.001 \
    run function \
        mcs_weather:weather/tornado/destroy