playsound \
    block.dry_grass.ambient block @a[distance=..64] ~ ~ ~ 4 1.5
playsound \
    entity.phantom.flap block @a[distance=..64] ~ ~ ~ 4 0.5
execute \
    if predicate mcs_weather:chance/0.1 \
    run playsound \
        ambient.soul_sand_valley.mood block @a[distance=..64] ~ ~ ~ 4 1.5
execute \
    if predicate mcs_weather:chance/0.1 \
    run playsound \
        entity.vex.ambient block @a[distance=..64] ~ ~ ~ 4 0.5