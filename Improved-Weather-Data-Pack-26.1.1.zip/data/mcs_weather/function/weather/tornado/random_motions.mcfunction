execute \
    if predicate mcs_weather:chance/0.2 \
    run data \
        modify entity @s Motion[0] set value 0.2
execute \
    if predicate mcs_weather:chance/0.2 \
    run data \
        modify entity @s Motion[0] set value -0.2
data \
    modify entity @s Motion[1] set value 0.2
execute \
    if predicate mcs_weather:chance/0.2 \
    run data \
        modify entity @s Motion[2] set value 0.2
execute \
    if predicate mcs_weather:chance/0.2 \
    run data \
        modify entity @s Motion[2] set value -0.2