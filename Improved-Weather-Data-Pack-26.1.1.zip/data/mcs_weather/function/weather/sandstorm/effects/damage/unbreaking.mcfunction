execute \
    if predicate mcs_weather:armor/leather_helmet/unbreaking/1 \
    if predicate mcs_weather:chance/0.5 \
    run item \
        modify entity @s armor.head mcs_weather:damage/leather_helmet
execute \
    if predicate mcs_weather:armor/leather_helmet/unbreaking/2 \
    if predicate mcs_weather:chance/0.33 \
    run item \
        modify entity @s armor.head mcs_weather:damage/leather_helmet
execute \
    if predicate mcs_weather:armor/leather_helmet/unbreaking/3 \
    if predicate mcs_weather:chance/0.25 \
    run item \
        modify entity @s armor.head mcs_weather:damage/leather_helmet