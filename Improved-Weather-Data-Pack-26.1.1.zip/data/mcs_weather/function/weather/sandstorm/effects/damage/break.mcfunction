particle \
    item{item:leather} ~ ~1 ~ 0.5 0.5 0.5 0.01 16 normal
playsound \
    entity.item.break player @a[distance=..16] ~ ~ ~ 1 1
item \
    replace entity @s armor.head with air