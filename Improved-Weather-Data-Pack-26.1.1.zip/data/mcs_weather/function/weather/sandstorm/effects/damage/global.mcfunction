execute \
    if predicate mcs_weather:armor/leather_helmet/unbreaking/global \
    run function \
        mcs_weather:weather/sandstorm/effects/damage/unbreaking
execute \
    unless predicate mcs_weather:armor/leather_helmet/unbreaking/global \
    run item \
        modify entity @s armor.head mcs_weather:damage/leather_helmet
execute \
    if predicate mcs_weather:armor/leather_helmet/break \
    run function \
        mcs_weather:weather/sandstorm/effects/damage/break