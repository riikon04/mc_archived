effect \
    give @s slowness 8 1 true
effect \
    give @s mining_fatigue 8 0 true
effect \
    give @s blindness 4 0 true
execute \
    if predicate mcs_weather:chance/0.1 \
    run damage \
        @s 1 in_wall at ~ ~ ~
particle \
    falling_dust{block_state:sand} ~ ~1 ~ 0.5 0.5 0.5 0.01 16 normal