effect \
    give @s slowness 8 2 true
effect \
    give @s mining_fatigue 8 1 true
effect \
    give @s blindness 6 0 true
execute \
    if predicate mcs_weather:chance/0.2 \
    run damage \
        @s 1 in_wall at ~ ~ ~
particle \
    falling_dust{block_state:sand} ~ ~1 ~ 0.5 0.5 0.5 0.01 4 normal
execute \
    if entity @s[type=player,\
        predicate=mcs_weather:armor/leather_helmet/item,\
        predicate=mcs_weather:chance/0.2] \
    run function \
        mcs_weather:weather/sandstorm/effects/damage/global