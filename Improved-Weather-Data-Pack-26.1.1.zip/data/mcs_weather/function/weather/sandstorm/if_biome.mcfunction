execute \
    unless score @s mcs_weather_sandstorm matches 16.. \
    if block ~ ~-1 ~ sand \
    run scoreboard \
        players add @s mcs_weather_sandstorm 2
execute \
    unless score @s mcs_weather_sandstorm2 matches 16.. \
    if block ~ ~-1 ~ red_sand \
    run scoreboard \
        players add @s mcs_weather_sandstorm2 2