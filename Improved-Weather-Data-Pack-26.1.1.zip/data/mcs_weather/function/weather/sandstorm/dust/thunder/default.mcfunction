particle \
    dust_color_transition{from_color:[0.906,0.894,0.733],\
        scale:4,\
        to_color:[0.855,0.812,0.639]} ~ ~4 ~ 16 4 16 1 320 force
particle \
    falling_dust{block_state:sand} ~ ~4 ~ 16 4 16 1 80 force