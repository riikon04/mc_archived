particle \
    dust_color_transition\
        {from_color:[0.824,0.459,0.169],\
        scale:4,\
        to_color:[0.749,0.404,0.129]} ~ ~4 ~ 16 4 16 1 320 force
particle \
    falling_dust{block_state:red_sand} ~ ~4 ~ 16 4 16 1 80 force