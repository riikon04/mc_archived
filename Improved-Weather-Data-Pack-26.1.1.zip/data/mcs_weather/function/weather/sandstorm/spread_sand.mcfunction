execute \
    store result score @s mcs_weather.random_number \
    run random \
        value 1..2
execute \
    if score @s mcs_weather_sandstorm matches 1.. \
    if score @s mcs_weather.random_number matches 1 \
    run setblock \
        ~ ~-1 ~ sand replace
execute \
    if score @s mcs_weather_sandstorm2 matches 1.. \
    if score @s mcs_weather.random_number matches 2 \
    run setblock \
        ~ ~-1 ~ red_sand replace
scoreboard \
    players reset @s mcs_weather.random_number