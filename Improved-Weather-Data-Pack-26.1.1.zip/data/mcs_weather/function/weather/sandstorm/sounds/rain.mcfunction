execute \
    if predicate mcs_weather:chance/0.2 \
    run playsound \
        ambient.soul_sand_valley.additions ambient @a[distance=..32] ~ ~ ~ 2 0.5
execute \
    if predicate mcs_weather:chance/0.2 \
    run playsound \
        ambient.soul_sand_valley.additions ambient @a[distance=..32] ~ ~ ~ 2 1
execute \
    if predicate mcs_weather:chance/0.2 \
    run playsound \
        ambient.soul_sand_valley.additions ambient @a[distance=..32] ~ ~ ~ 2 1.5
execute \
    if predicate mcs_weather:chance/0.2 \
    run playsound \
        block.dry_grass.ambient hostile @a[distance=..32] ~ ~ ~ 2 0.5
execute \
    if predicate mcs_weather:chance/0.2 \
    run playsound \
        block.dry_grass.ambient ambient @a[distance=..32] ~ ~ ~ 2 1
execute \
    if predicate mcs_weather:chance/0.2 \
    run playsound \
        block.dry_grass.ambient ambient @a[distance=..32] ~ ~ ~ 2 1.5
execute \
    if predicate mcs_weather:chance/0.2 \
    run playsound \
        block.sand.idle hostile @a[distance=..32] ~ ~ ~ 2 0.5
execute \
    if predicate mcs_weather:chance/0.2 \
    run playsound \
        block.sand.idle ambient @a[distance=..32] ~ ~ ~ 2 1
execute \
    if predicate mcs_weather:chance/0.2 \
    run playsound \
        block.sand.idle ambient @a[distance=..32] ~ ~ ~ 2 1.5