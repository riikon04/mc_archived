execute \
    if score @s mcs_weather_sandstorm matches 1.. \
    run scoreboard \
        players remove @s mcs_weather_sandstorm 1
execute \
    if score @s mcs_weather_sandstorm2 matches 1.. \
    run scoreboard \
        players remove @s mcs_weather_sandstorm2 1