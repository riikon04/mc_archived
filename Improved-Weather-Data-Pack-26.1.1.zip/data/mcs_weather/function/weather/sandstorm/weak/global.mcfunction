execute \
        if predicate mcs_weather:score/sandstorm \
        run function \
                mcs_weather:weather/sandstorm/weak/if_sand
execute \
        if biome ~ ~ ~ #mcs_weather:has_sandstorms \
        if block ~ ~-1 ~ #sand \
        run function \
                mcs_weather:weather/sandstorm/if_biome