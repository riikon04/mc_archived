execute \
    if score @s mcs_weather_sandstorm matches 1.. \
    unless score @s mcs_weather_sandstorm2 matches 1.. \
    run function \
        mcs_weather:weather/sandstorm/dust/rain/default
execute \
    if score @s mcs_weather_sandstorm2 matches 1.. \
    unless score @s mcs_weather_sandstorm matches 1.. \
    run function \
        mcs_weather:weather/sandstorm/dust/rain/red
execute \
    if score @s mcs_weather_sandstorm matches 1.. \
    if score @s mcs_weather_sandstorm2 matches 1.. \
    run function \
        mcs_weather:weather/sandstorm/dust/rain/mix
execute \
    as @e[type=!#mcs_weather:immune_to_sandstorm,\
        predicate=mcs_weather:location/can_see_sky,\
        predicate=!mcs_weather:players/op,\
        predicate=!mcs_weather:armor/leather_helmet/item,\
        distance=..8] at @s \
    run function \
        mcs_weather:weather/sandstorm/effects/rain
execute \
    as @a[predicate=mcs_weather:armor/leather_helmet/item,\
        predicate=mcs_weather:chance/0.1,\
        distance=..8] at @s \
    run function \
        mcs_weather:weather/sandstorm/effects/damage/global
execute \
    if entity @p[distance=..32] \
    run function \
        mcs_weather:weather/sandstorm/sounds/rain
execute \
    if score @s do_sandstorm_sand_spreading matches 1.. \
    if predicate mcs_weather:chance/0.1 \
    if block ~ ~-1 ~ #dirt \
    run function \
        mcs_weather:weather/sandstorm/spread_sand
execute \
    unless block ~ ~-1 ~ #sand \
    run function \
        mcs_weather:weather/sandstorm/decrease
execute \
    unless biome ~ ~-1 ~ #mcs_weather:has_sandstorms \
    run function \
        mcs_weather:weather/sandstorm/decrease