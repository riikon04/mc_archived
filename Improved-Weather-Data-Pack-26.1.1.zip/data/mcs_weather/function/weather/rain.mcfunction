execute \
    if score $mcs_weather do_dynamic_snow_accumulation matches 1 \
    if biome ~ ~ ~ #mcs_weather:is_cold \
    if block ~ ~-1 ~ #mcs_weather:snow_fill_blocks \
    run function \
        mcs_weather:biomes/snowy_biomes/snowstorm
execute \
    if score $mcs_weather do_dry_weather_in_savanna matches 1 \
    if biome ~ ~ ~ #is_savanna \
    if predicate mcs_weather:chance/0.02 \
    if predicate mcs_weather:time/2000..11000 \
    if block ~ ~-1 ~ #mcs_weather:on_fire_blocks \
    run function \
        mcs_weather:biomes/savanna/choose_event
execute \
    if score $mcs_weather do_floods matches 1 \
    if biome ~ ~ ~ #mcs_weather:is_wet \
    if predicate mcs_weather:chance/0.02 \
    if block ~ ~-1 ~ #mcs_weather:flood_spawns_on \
    run function .summon:mcs_weather/flood
execute \
    if score $mcs_weather do_sandstorms matches 1 \
    run function \
        mcs_weather:weather/sandstorm/weak/global
execute \
    if score $mcs_weather do_rian_extinguish_campfires matches 1 \
    if block ~ ~-1 ~ #campfires[lit=true] \
    run function \
        mcs_weather:blocks/campfire/rain/global