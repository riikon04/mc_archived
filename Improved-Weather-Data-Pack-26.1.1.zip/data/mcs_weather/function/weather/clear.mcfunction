execute \
    if predicate mcs_weather:score/sandstorm \
    run function \
        mcs_weather:weather/sandstorm/decrease
execute \
    if score $mcs_weather do_fog_in_wet_biomes matches 1 \
    if biome ~ ~ ~ #mcs_weather:is_wet \
    if predicate mcs_weather:time/fog \
    if predicate mcs_weather:light/min8 \
    run particle \
        cloud ~ ~16 ~ 16 16 16 0.01 512 force
execute \
    if score $mcs_weather do_fire_flies_spawning matches 1 \
    if biome ~ ~ ~ #mcs_weather:has_fireflies \
    if predicate mcs_weather:light/max7 \
    run function \
        mcs_weather:effects/firefly
execute \
    if score $mcs_weather do_snow_melting matches 1 \
    if predicate mcs_weather:light/12..15 \
    if block ~ ~-1 ~ snow \
    run function \
        mcs_weather:biomes/snowy_biomes/melting/global
execute \
    if score $mcs_weather do_waves matches 1 \
    if biome ~ ~ ~ #is_ocean \
    if predicate mcs_weather:location/y/60..70 \
    if predicate mcs_weather:chance/0.01 \
    if block ~ ~-1 ~ #mcs_weather:water \
    run function \
        .summon:mcs_weather/flood