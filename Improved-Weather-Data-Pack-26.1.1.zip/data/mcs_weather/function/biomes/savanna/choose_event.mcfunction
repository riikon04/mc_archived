execute \
    store result score @s mcs_weather.random_number3 \
    run random \
        value 1..2
execute \
    if score @s mcs_weather.random_number3 matches 1 \
    run function \
        .summon:mcs_weather/savanna_fire
execute \
    if score @s mcs_weather.random_number3 matches 2 \
    run summon \
        lightning_bolt ~ ~ ~
scoreboard \
    players reset @s mcs_weather.random_number3