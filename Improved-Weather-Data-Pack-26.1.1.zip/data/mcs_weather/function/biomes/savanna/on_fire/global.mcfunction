particle \
    campfire_signal_smoke ~ ~16 ~ 4 16 4 0.01 16 force
particle \
    flame ~ ~4 ~ 1 4 1 0.01 64 force
execute \
    if entity @p[distance=..32] \
    run playsound \
        entity.blaze.burn ambient @a[distance=..32] ~ ~ ~ 2 0.5
execute \
    unless block ~ ~ ~ #mcs_weather:massive_fire_extinguish \
    run function \
        mcs_weather:biomes/savanna/remove_fire
execute \
    if predicate mcs_weather:chance/0.05 \
    run function \
        mcs_weather:biomes/savanna/remove_fire
execute \
    store result entity @s data.fire_x int 1 \
    run random \
        value -2..2
execute \
    store result entity @s data.fire_y int 1 \
    run random \
        value -1..1
execute \
    store result entity @s data.fire_z int 1 \
    run random \
        value -2..2
execute \
    store result entity @s data.fire_x2 int 1 \
    run random \
        value -2..2
execute \
    store result entity @s data.fire_y2 int 1 \
    run random \
        value -1..1
execute \
    store result entity @s data.fire_z2 int 1 \
    run random \
        value -2..2
function \
    mcs_weather:biomes/savanna/on_fire/apply \
    with entity @s data
execute \
    store result score @s mcs_weather.random_number \
    run random \
        value 1..6
execute \
    if score @s mcs_weather.random_number matches 1 \
    if block ~1 ~ ~ #replaceable \
    run tp \
        @s ~1 ~ ~
execute \
    if score @s mcs_weather.random_number matches 2 \
    if block ~ ~ ~1 #replaceable \
    run tp \
        @s ~ ~ ~1
execute \
    if score @s mcs_weather.random_number matches 3 \
    if block ~-1 ~ ~ #replaceable \
    run tp \
        @s ~-1 ~ ~
execute \
    if score @s mcs_weather.random_number matches 4 \
    if block ~ ~ ~-1 #replaceable \
    run tp \
        @s ~ ~ ~-1
execute \
    if score @s mcs_weather.random_number matches 5 \
    if block ~ ~1 ~ #replaceable \
    run tp \
        @s ~ ~1 ~
execute \
    if score @s mcs_weather.random_number matches 6 \
    if block ~ ~-1 ~ #replaceable \
    run tp \
        @s ~ ~-1 ~
scoreboard \
    players reset @s mcs_weather.random_number