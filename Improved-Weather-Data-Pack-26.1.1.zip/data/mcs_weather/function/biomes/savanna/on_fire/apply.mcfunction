$fill \
    ~$(fire_x) ~$(fire_y) ~$(fire_z) ~$(fire_x2) ~$(fire_y2) ~$(fire_z2) \
    fire replace #replaceable destroy