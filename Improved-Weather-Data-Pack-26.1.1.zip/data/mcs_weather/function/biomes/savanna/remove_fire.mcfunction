particle \
    campfire_signal_smoke \
    ~ ~16 ~ 8 16 8 0.1 16 force
execute \
    if entity @p[distance=..32] \
    run particle \
        cloud ~ ~1 ~ 1 1 1 0.01 32 normal
execute \
    if entity @p[distance=..32] \
    run playsound \
        block.fire.extinguish ambient @a[distance=..32] ~ ~ ~ 2 1
kill \
    @s