execute \
    if block ~ ~-1 ~ farmland \
    run setblock \
        ~ ~-1 ~ dirt replace
execute \
    if block ~ ~-1 ~ dirt_path \
    run setblock \
        ~ ~-1 ~ dirt replace
execute \
    if block ~ ~-1 ~ magma_block \
    run setblock \
        ~ ~-1 ~ basalt replace
execute \
    if block ~ ~-1 ~ lava \
    run setblock \
        ~ ~-1 ~ magma_block replace