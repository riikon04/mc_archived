execute \
    if block ~ ~-1 ~ snow[layers=1] \
    run function \
        mcs_weather:biomes/snowy_biomes/melting/finish
execute \
    if block ~ ~-1 ~ snow[layers=2] \
    run setblock \
        ~ ~-1 ~ snow[layers=1] replace
execute \
    if block ~ ~-1 ~ snow[layers=3] \
    run setblock \
        ~ ~-1 ~ snow[layers=2] replace
execute \
    if block ~ ~-1 ~ snow[layers=4] \
    run setblock \
        ~ ~-1 ~ snow[layers=3] replace
execute \
    if block ~ ~-1 ~ snow[layers=5] \
    run setblock \
        ~ ~-1 ~ snow[layers=4] replace
execute \
    if block ~ ~-1 ~ snow[layers=6] \
    run setblock \
        ~ ~-1 ~ snow[layers=5] replace
execute \
    if block ~ ~-1 ~ snow[layers=7] \
    run setblock \
        ~ ~-1 ~ snow[layers=6] replace
execute \
    if block ~ ~-1 ~ snow[layers=8] \
    run setblock \
        ~ ~-1 ~ snow[layers=7] replace