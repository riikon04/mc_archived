execute \
    unless biome ~ ~ ~ #mcs_weather:is_cold \
    run function \
        mcs_weather:biomes/snowy_biomes/melting/check
execute \
    if biome ~ ~ ~ #mcs_weather:is_cold \
    if predicate mcs_weather:chance/0.2 \
    run function \
        mcs_weather:biomes/snowy_biomes/melting/cold