execute \
    if biome ~ ~ ~ #mcs_weather:is_dry \
    run fill \
        ~1 ~-1 ~1 ~-1 ~-1 ~-1 \
        water[level=15] replace snow
execute \
    unless biome ~ ~ ~ #mcs_weather:is_dry \
    run function \
        mcs_weather:biomes/snowy_biomes/melting/start