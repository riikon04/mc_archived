execute \
    if entity @p[distance=..16] \
    run playsound \
        entity.generic.splash ambient @a[distance=..16] ~ ~ ~ 1 1
fill \
    ~1 ~-1 ~1 ~-1 ~-1 ~-1 \
    water[level=15] replace snow[layers=1]