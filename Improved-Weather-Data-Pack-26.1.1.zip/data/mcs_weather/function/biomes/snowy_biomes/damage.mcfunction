execute \
    if predicate mcs_weather:weather/rain \
    run damage \
        @s 2 freeze at ~ ~ ~
execute \
    if predicate mcs_weather:weather/thunder \
    run damage \
        @s 4 freeze at ~ ~ ~