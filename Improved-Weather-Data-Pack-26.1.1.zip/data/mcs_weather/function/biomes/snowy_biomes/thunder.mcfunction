execute \
    if block ~ ~-3 ~ snow_block \
    run setblock \
        ~ ~-3 ~ powder_snow replace
execute \
    if block ~ ~-1 ~ snow[layers=8] \
    run setblock \
        ~ ~-1 ~ snow_block replace