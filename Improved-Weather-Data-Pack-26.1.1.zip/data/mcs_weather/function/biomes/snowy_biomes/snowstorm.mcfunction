execute \
    if predicate mcs_weather:weather/thunder \
    run function \
        mcs_weather:biomes/snowy_biomes/thunder
fill \
    ~1 ~ ~1 ~-1 ~-1 ~-1 \
    snow[layers=1] replace #mcs_weather:snow_layer_replaces
execute \
    if block ~ ~-1 ~ #mcs_weather:snow_affects \
    run function \
        mcs_weather:biomes/snowy_biomes/affect/global
particle \
    falling_dust{block_state:snow} \
    ~ ~2 ~ 1 1 1 0.01 16 force
execute \
    if entity @p[distance=..16] \
    run playsound \
        entity.player.hurt_freeze \
        block @a[distance=..16] ~ ~ ~ 1 0.5
execute \
    as @e[type=!#mcs_weather:ignore,\
        type=!#freeze_immune_entity_types,\
        predicate=!mcs_weather:effects/immune_to_freeze,\
        predicate=!mcs_weather:light/12..15,\
        distance=..8] at @s \
    run function \
        mcs_weather:biomes/snowy_biomes/damage