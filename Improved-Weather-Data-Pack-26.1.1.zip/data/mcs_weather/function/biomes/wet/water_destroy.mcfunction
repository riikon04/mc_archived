execute \
    if entity @p[distance=..32] \
    run particle \
        cloud ~ ~1 ~ 1 1 1 0.01 32 normal
execute \
    if entity @p[distance=..32] \
    run playsound \
        entity.generic.splash ambient @a[distance=..32] ~ ~ ~ 2 1
kill \
    @s