$fill \
    ~$(water_x) ~$(water_y) ~$(water_z) ~$(water_x2) ~$(water_y2) ~$(water_z2) \
    water[level=15] replace #replaceable destroy