execute \
    if entity @p[distance=..32] \
    run particle \
        block{block_state:"water"} ~ ~2 ~ 2 2 2 1 32 normal
execute \
    if predicate mcs_weather:chance/0.25 \
    run playsound \
        entity.generic.swim ambient @a[distance=..32] ~ ~ ~ 2 0.5
execute \
    unless block ~ ~ ~ #mcs_weather:flood_dissapear \
    run function \
        mcs_weather:biomes/wet/water_destroy
execute \
    if predicate mcs_weather:chance/0.05 \
    run function \
        mcs_weather:biomes/wet/water_destroy
execute \
    store result entity @s data.water_x int 1 \
    run random \
        value -4..4
execute \
    store result entity @s data.water_y int 1 \
    run random \
        value -1..1
execute \
    store result entity @s data.water_z int 1 \
    run random \
        value -4..4
execute \
    store result entity @s data.water_x2 int 1 \
    run random \
        value -4..4
execute \
    store result entity @s data.water_y2 int 1 \
    run random \
        value -1..1
execute \
    store result entity @s data.water_z2 int 1 \
    run random \
        value -4..4
function \
    mcs_weather:biomes/wet/water/apply \
    with entity @s data
execute \
    store result score @s mcs_weather.random_number \
    run random \
        value 1..6
execute \
    if score @s mcs_weather.random_number matches 1 \
    if block ~1 ~ ~ #replaceable \
    run tp \
        @s ~1 ~ ~
execute \
    if score @s mcs_weather.random_number matches 2 \
    if block ~ ~ ~1 #replaceable \
    run tp \
        @s ~ ~ ~1
execute \
    if score @s mcs_weather.random_number matches 3 \
    if block ~-1 ~ ~ #replaceable \
    run tp \
        @s ~-1 ~ ~
execute \
    if score @s mcs_weather.random_number matches 4 \
    if block ~ ~ ~-1 #replaceable \
    run tp \
        @s ~ ~ ~-1
execute \
    if score @s mcs_weather.random_number matches 5 \
    if block ~ ~1 ~ #replaceable \
    run tp \
        @s ~ ~1 ~
execute \
    if score @s mcs_weather.random_number matches 6 \
    if block ~ ~-1 ~ #replaceable \
    run tp \
        @s ~ ~-1 ~
scoreboard \
    players reset @s mcs_weather.random_number