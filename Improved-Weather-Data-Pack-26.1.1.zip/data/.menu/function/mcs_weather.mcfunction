execute \
    unless score $mcs_weather mcs_weather.uninstall_mode matches 1 \
    run dialog \
        show @s mcs_weather:menu
execute \
    if score $mcs_weather mcs_weather.uninstall_mode matches 1 \
    run function \
        mcs_weather:code/uninstall/text2