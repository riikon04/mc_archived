dialog \
    show @s mcs_weather:uninstall