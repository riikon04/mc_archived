setblock ~ ~ ~ air
kill @s

