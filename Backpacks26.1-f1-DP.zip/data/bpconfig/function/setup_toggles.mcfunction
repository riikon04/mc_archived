execute unless score $CAN_PLACE_BACKPACKS_V ulg_gen matches 1.. run scoreboard players set $CAN_PLACE_BACKPACKS ulg_gen 1
scoreboard players set $CAN_PLACE_BACKPACKS_V ulg_gen 1
execute unless score $CAN_MODIFY_BACKPACKS_V ulg_gen matches 1.. run scoreboard players set $CAN_MODIFY_BACKPACKS ulg_gen 1
scoreboard players set $CAN_MODIFY_BACKPACKS_V ulg_gen 1
execute unless score $TABLE_BACKPACKS_TICK_V ulg_gen matches 1.. run scoreboard players set $TABLE_BACKPACKS_TICK ulg_gen 1
scoreboard players set $TABLE_BACKPACKS_TICK_V ulg_gen 1
execute unless score $NO_BOX_CHEAT_V ulg_gen matches 1.. run scoreboard players set $NO_BOX_CHEAT ulg_gen 1
scoreboard players set $NO_BOX_CHEAT_V ulg_gen 1
