### TOGGLES ###
#
scoreboard players set $CAN_PLACE_BACKPACKS ulg_gen 1
#1 is the default value for this toggle. Change is as needed
#
scoreboard players set $CAN_MODIFY_BACKPACKS ulg_gen 1
#1 is the default value for this toggle. Change is as needed
#
scoreboard players set $TABLE_BACKPACKS_TICK ulg_gen 1
#1 is the default value for this toggle. Change is as needed
#
scoreboard players set $NO_BOX_CHEAT ulg_gen 1
#1 is the default value for this toggle. Change is as needed
#
