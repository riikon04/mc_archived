say SPLIT SETUPS
execute unless score $BP_VERSION ulg_gen matches 0.. run return run function ulg:bp/setup_controller/setup/split_setups/first_setup
function ulg:bp/setup_controller/setup/split_setups/next_setup
