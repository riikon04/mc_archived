data modify storage ulg:temp inv set from entity @s Inventory
data remove storage ulg:temp inv[{Slot: -106b}]
execute if data storage ulg:temp inv[].components."minecraft:custom_data".bp.Inventory[{}] run function ulg:bp/sub/eject_offhand_backpack
