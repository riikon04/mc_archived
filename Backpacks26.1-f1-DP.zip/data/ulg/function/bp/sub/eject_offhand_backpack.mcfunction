tellraw @s {"text": "Bạn chỉ được sử dụng 1 balo có chứa đồ cùng lúc!", "color": "red"}
summon minecraft:item ~ ~ ~ {Item: {id: "minecraft:stone", count: 1b}, Tags: ["ulg_eject_bp"]}
data modify entity @e[type=item,tag=ulg_eject_bp,limit=1,sort=nearest] Item.id set from entity @s equipment.offhand.id
data modify entity @e[type=item,tag=ulg_eject_bp,limit=1,sort=nearest] Item.count set from entity @s equipment.offhand.count
data modify entity @e[type=item,tag=ulg_eject_bp,limit=1,sort=nearest] Item.components set from entity @s equipment.offhand.components
tag @e[type=item,tag=ulg_eject_bp] remove ulg_eject_bp
item replace entity @s weapon.offhand with air
playsound minecraft:entity.enderman.teleport player @s ~ ~ ~ 1 0.5
