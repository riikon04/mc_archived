execute if score $NO_BOX_CHEAT ulg_gen matches 1.. if predicate ulg:bp/j/idzu24muqm run return run function ulg:bp/sub/convert_openedbackpacks/player_inventory_case/try_auto_close/nested_return_0
function ulg:bp/sub/convert_openedbackpacks/player_inventory_case/auto_close_macro with storage ulg:macro auto_close
