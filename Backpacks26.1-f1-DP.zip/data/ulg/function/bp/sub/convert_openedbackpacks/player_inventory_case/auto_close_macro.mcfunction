data remove storage ulg:backpack intick
$data modify storage ulg:backpack intick.BackPackInventorySource set from entity @s Inventory[{Slot:$(Slot)b}].components."minecraft:custom_data".bp.Inventory
function ulg:bp/recallable/u02e7bfcae1e44aa8
$item modify entity @s container.$(Slot) ulg:bp/j/id96mp82wu
$item modify entity @s container.$(Slot) ulg:bp/j/idulfnma1x
scoreboard players reset @s ulg_bp_using
$function ulg:bp/sub/set_container_comp/do {dataPath:"Inventory[{Slot:$(Slot)b}]",containerString:"container.$(Slot)"}
title @s[tag=!ulg_knowsbackpack2] actionbar {translate: "ulg.alert.auto_closed", color: "#ed7666"}
tag @s[tag=!ulg_knowsbackpack2] add ulg_knowsbackpack2
