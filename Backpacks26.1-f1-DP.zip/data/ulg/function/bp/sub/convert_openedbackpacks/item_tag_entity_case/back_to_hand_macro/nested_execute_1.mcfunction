scoreboard players set $test.for.duplicate ulg_intick 1
data modify storage ulg:macro test.for.duplicate.p set value {}
data modify storage ulg:macro test.for.duplicate.p set from entity @p[tag=ulg_intick262] Inventory[{Slot:-106b}].components."minecraft:custom_data".bp.id
execute store result score $test.for.duplicate ulg_intick run data modify storage ulg:macro test.copy.p set from entity @s Item.components."minecraft:custom_data".bp.id
execute if score $test.for.duplicate ulg_intick matches 0 run function ulg:bp/sub/convert_openedbackpacks/item_tag_entity_case/back_to_hand_macro/nested_execute_0
data modify storage ulg:macro test.for.duplicate.p set value {}
