scoreboard players add @p[tag=ulg_intick262] ulg_bp_cheat 10
data remove entity @s Item
