summon minecraft:armor_stand ~ -1 ~ {Marker: 1b, Invisible: 1b, Tags: ["ulg_intick8360"], Invulnerable: 1b, NoGravity: 1b}
data modify entity @n[tag=ulg_intick8360] equipment.head set from entity @s Item
function ulg:bp/sub/convert_openedbackpacks/item_tag_entity_case/back_to_hand_macro with entity @s Item.components."minecraft:custom_data".bp.id
kill @e[type=minecraft:armor_stand, tag=ulg_intick8360]
