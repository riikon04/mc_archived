$tag @p[scores={ulg_bp_using=$(uniq)}] add ulg_intick262
tellraw @p[tag=ulg_intick262] {translate: "ulg.alert.no_drop_open", fallback: "You can't drop the backpack, it's still open!", color: "#ed7666"}
scoreboard players add @p[tag=ulg_intick262] ulg_bp_cheat 5
execute unless data entity @p[tag=ulg_intick262] equipment.offhand run return run function ulg:bp/sub/convert_openedbackpacks/item_tag_entity_case/back_to_hand_macro/case_offhand_free
data modify entity @s Item set from entity @p[tag=ulg_intick262] equipment.offhand
item replace entity @p[tag=ulg_intick262] weapon.offhand from entity @n[tag=ulg_intick8360] armor.head
execute if data entity @s Item.components."minecraft:custom_data".bp.id if data entity @p[tag=ulg_intick262] equipment.offhand.components."minecraft:custom_data".bp.id run function ulg:bp/sub/convert_openedbackpacks/item_tag_entity_case/back_to_hand_macro/nested_execute_1
tag @a remove ulg_intick262
