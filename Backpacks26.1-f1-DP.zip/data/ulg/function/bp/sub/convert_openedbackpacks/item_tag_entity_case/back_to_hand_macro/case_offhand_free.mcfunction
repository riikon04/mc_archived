item replace entity @p[tag=ulg_intick262] weapon.offhand from entity @n[tag=ulg_intick8360] armor.head
data remove entity @s Item
kill @s[type=minecraft:item]
tag @a remove ulg_intick262
