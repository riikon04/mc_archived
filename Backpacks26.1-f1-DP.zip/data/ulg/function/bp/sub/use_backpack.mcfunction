# Check for false/0b
execute if data entity @s equipment.offhand.components."minecraft:custom_data".bp{Opened: false} run tag @s add ulg_intick824
execute if data entity @s equipment.offhand.components."minecraft:custom_data".bp{Opened: 0b} run tag @s add ulg_intick824

# If closed, open it
execute as @s[tag=ulg_intick824] run function ulg:bp/recallable/u497d7fcc806b4a40

# If opened, close it
execute as @s[tag=!ulg_intick824] if data entity @s equipment.offhand.components."minecraft:custom_data".bp{Opened: true} run function ulg:bp/recallable/u36eb34bdc44d4a53
execute as @s[tag=!ulg_intick824] if data entity @s equipment.offhand.components."minecraft:custom_data".bp{Opened: 1b} run function ulg:bp/recallable/u36eb34bdc44d4a53

tag @s remove ulg_intick824
