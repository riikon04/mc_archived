particle minecraft:dust{color: [1.0d, 0.827d, 0.129d], scale: 0.5d} ~ ~0.4 ~ 0.2 0.2 0.2 1 20 normal @a[distance=..6, tag=ulg.intick.target]
summon minecraft:item ~ 0 ~ {Tags: ["ulg_intick151", "global.ignore"], Item: {id: "minecraft:carrot", count: 1b}}
data modify entity @e[type=item, tag=ulg_intick151, limit=1] Item set from entity @s ArmorItems[3]
kill @e[type=interaction, tag=ulg.backpackModifiable.hitbox, distance=..0.1, sort=nearest, limit=1]
kill @s
execute at @s run playsound minecraft:item.bundle.remove_one block @a[distance=..10] ~ ~ ~ 1 1 0.1
tp @e[type=item, tag=ulg_intick151, limit=1] ~ ~0.3 ~
tag @e remove ulg_intick151
