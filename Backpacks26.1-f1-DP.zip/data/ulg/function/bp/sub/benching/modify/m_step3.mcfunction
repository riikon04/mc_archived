$clear @a[tag=ulg.intick.target,limit=1] $(itemId) 1
data modify entity @s equipment.head.components."minecraft:custom_data".bp.dirty set value 1b
return 1
