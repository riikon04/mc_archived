execute at @s run playsound minecraft:item.dye.use block @a[distance=..10] ~ ~ ~ 0.5 0.5
execute unless score @s ulg_gen matches -1..10 run scoreboard players set @s ulg_gen -1
$execute if data storage ulg:backpack table_modifs.backpackModels[{id:"$(currentModel)"}].directTransform."$(itemId)" run return run function ulg:bp/sub/benching/modify/m_step0_alt with storage ulg:macro table_modify
$execute unless data storage ulg:backpack table_modifs.backpackModels[{id:"$(currentModel)"}].layers run return fail
data modify storage ulg:macro table_modify.itemGroupId set value "null"
$data modify storage ulg:macro table_modify.itemGroupId set from storage ulg:backpack table_modifs.itemGroups[{values:[{item:"$(itemId)"}]}].id
execute if data storage ulg:macro table_modify{itemGroupId: "null"} run return fail
return run function ulg:bp/sub/benching/modify/m_step1 with storage ulg:macro table_modify
