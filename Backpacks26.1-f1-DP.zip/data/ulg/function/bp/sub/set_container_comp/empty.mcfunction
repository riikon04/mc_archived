$item modify entity @s $(containerString) {function:"minecraft:set_components",components:{"minecraft:container":[]}}
