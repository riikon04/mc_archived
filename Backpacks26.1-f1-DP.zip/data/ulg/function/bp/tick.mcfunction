execute as @e[type=#ulg:bp/tick/entities] run function ulg:bp/tick/nested_execute_5
