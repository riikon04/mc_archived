scoreboard objectives add ulg_gen dummy
scoreboard objectives add ulg_intick dummy
scoreboard objectives add ulg_intick1 dummy
scoreboard objectives add ulg_intick2 dummy
scoreboard objectives add ulg_macro dummy
execute unless score $BP_VERSION ulg_gen matches 2601991.. run function ulg:bp/setup_controller/setup
scoreboard players set $BP_VERSION ulg_gen 2601991
