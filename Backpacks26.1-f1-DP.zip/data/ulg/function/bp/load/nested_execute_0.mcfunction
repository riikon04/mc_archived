execute store result score $ULG_BP_WORLDID ulg_gen run random value 1..99999
scoreboard players set $ULG_BP_IDCOUNT ulg_gen 0
