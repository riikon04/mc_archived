execute if data entity @s Inventory[{Slot:-106b}].components{"minecraft:custom_data": {bp: {newV: 2b}}} run function ulg:bp/sub/init26/update
function ulg:bp/sub/init26/check_id
data remove storage ulg:backpack intick
data modify storage ulg:backpack intick.BackPackName set from entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".display.Name
data modify storage ulg:backpack intick.BackPackInventorySource set from entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".bp.Inventory
function ulg:bp/recallable/u02e7bfcae1e44aa8
item modify entity @s weapon.offhand ulg:bp/j/idsfr4uqy6
item modify entity @s weapon.offhand ulg:bp/j/idulfnma1x
execute at @s run playsound minecraft:item.lead.tied master @s ~ ~ ~ 0.3 0.6 0.2
execute unless entity @s[tag=ulg_knowsbackpack] run tellraw @s {translate: "ulg.alert.checkyourinventory", color: "#ed7666"}
tag @s[tag=!ulg_knowsbackpack] add ulg_knowsbackpack
execute store result score @s ulg_bp_using run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".bp.id.uniq
