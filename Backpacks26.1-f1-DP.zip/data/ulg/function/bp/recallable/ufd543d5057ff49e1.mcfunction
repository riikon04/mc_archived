data remove storage ulg:backpack intick
data modify storage ulg:backpack intick.BackPackInventorySource set from entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".bp.Inventory
function ulg:bp/recallable/u02e7bfcae1e44aa8
item modify entity @s weapon.offhand ulg:bp/j/id96mp82wu
item modify entity @s weapon.offhand ulg:bp/j/idulfnma1x
execute at @s run playsound minecraft:item.lead.untied master @s ~ ~ ~ 0.3 0.6 0.2
scoreboard players reset @s ulg_bp_using
function ulg:bp/sub/set_container_comp/do {dataPath: "Inventory[{Slot:-106b}]", containerString: "weapon.offhand"}
