execute if score $NO_BOX_CHEAT ulg_gen matches 1.. run return run function ulg:bp/recallable/u36eb34bdc44d4a53/nested_return_0
function ulg:bp/recallable/ufd543d5057ff49e1
