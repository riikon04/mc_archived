setblock ~ ~ ~ minecraft:barrel replace
data modify block ~ ~ ~ Items set value []
setblock ~-1 ~ ~ minecraft:barrel replace
data modify block ~-1 ~ ~ Items set value []
data modify block ~ ~ ~ Items set from storage ulg:backpack intick.BackPackInventorySource
execute positioned ~-1 ~ ~ run function ulg:bp/recallable/u02e7bfcae1e44aa8/nested_execute_0
data modify storage ulg:backpack intick.BackPackInventory set from block ~-1 ~ ~ Items
function ulg:bp/recallable/u02e7bfcae1e44aa8/nested_execute_1
