execute if predicate ulg:bp/j/idspkq29hf run title @s[tag=!global.ignore.gui] actionbar {translate: "ulg.alert.nodoublebackpack", color: "#9D6F3D"}
execute if predicate ulg:bp/j/idhmglpuqi run title @s[tag=!global.ignore.gui] actionbar {translate: "ulg.alert.nobundlesinside", color: "#9D6F3D"}
execute if predicate ulg:bp/j/idttpguiyo run title @s[tag=!global.ignore.gui] actionbar {translate: "ulg.alert.noshboxesinside", color: "#9D6F3D"}
execute unless predicate ulg:bp/j/idzu24muqm run return run function ulg:bp/recallable/ufd543d5057ff49e1
