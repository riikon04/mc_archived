execute if block ~ ~-0.2 ~ minecraft:anvil if block ~ ~ ~ minecraft:anvil run return run execute align xyz positioned ~0.5 ~1 ~0.5 run function ulg:bp/sub/benching/tryplace
execute align xyz positioned ~0.5 ~ ~0.5 run function ulg:bp/sub/benching/tryplace
