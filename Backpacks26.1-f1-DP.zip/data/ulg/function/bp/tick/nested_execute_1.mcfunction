execute at @s run playsound minecraft:item.armor.equip_chain player @a[distance=..3] ~ ~ ~ 1 1 0.1
execute unless score @s ulg_bp_using matches 0.. if data entity @s equipment.offhand.components."minecraft:custom_data".bp{Opened: 1b} store result score @s ulg_bp_using run data get entity @s equipment.offhand.components."minecraft:custom_data".bp.id.uniq
tag @s add ulg.bp.carry
