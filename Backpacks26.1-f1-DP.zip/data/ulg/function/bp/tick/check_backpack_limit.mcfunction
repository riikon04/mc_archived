# Reset count
scoreboard players set @s ulg_bp_count 0

# Count opened backpacks (bp format - in offhand/recently opened)
execute store result score #temp_bp ulg_bp_count run clear @s *[custom_data~{bp:{}}] 0
scoreboard players operation @s ulg_bp_count += #temp_bp ulg_bp_count

# Count item-form backpacks (ulg.BackPack format - in inventory)
execute store result score #temp_bp ulg_bp_count run clear @s *[custom_data~{ulg:{BackPack:{}}}] 0
scoreboard players operation @s ulg_bp_count += #temp_bp ulg_bp_count

# Apply slowness if more than 2 backpacks (3+)
execute if score @s ulg_bp_count matches 2.. run effect give @s minecraft:slowness infinite 4 true
execute if score @s ulg_bp_count matches 2.. run tag @s add ulg_bp_slowness
execute if score @s ulg_bp_count matches 2.. run title @s actionbar {"text":"Bạn mang quá nhiều balo! Cần phải bỏ ra bớt!","color":"red"}

# Remove slowness when back to 1 or fewer
execute if score @s ulg_bp_count matches ..1 if entity @s[tag=ulg_bp_slowness] run effect clear @s minecraft:slowness
execute if score @s ulg_bp_count matches ..1 run tag @s remove ulg_bp_slowness
