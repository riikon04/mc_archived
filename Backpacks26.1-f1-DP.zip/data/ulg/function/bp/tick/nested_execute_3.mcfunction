execute if data entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".bp.newV run function ulg:bp/sub/use_backpack
execute if data entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ulg.BackPack unless data entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ulg.BackPack.newV run tellraw @s {translate: "ulg.alert.oldversionbackpack", color: "#ed7666", clickEvent: {action: "open_url", value: "https://sites.google.com/view/ultroghasthub/datapacks/backpacks/open_mouldy_backpack", underlined: true}}
scoreboard players reset @s ulg_bp_coas
