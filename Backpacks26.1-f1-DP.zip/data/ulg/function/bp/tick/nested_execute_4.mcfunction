execute if data entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ulg.BackPack unless data entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ulg.BackPack.newV run item modify entity @s weapon.offhand ulg:bp/j/idnpx5xesf
execute if data entity @s Inventory[].components."minecraft:custom_data".bp{Opened: 1b} unless data entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".bp{Opened: 1b} run function ulg:bp/sub/convert_openedbackpacks/player_inventory_case
execute if data entity @s Inventory[{components: {"minecraft:custom_data": {ulg: {BackPack: {newV: 1b}}}}}] run function ulg:bp/sub/fix25/act
execute as @s[tag=!ulg.bp.carry] if data entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".bp run function ulg:bp/tick/nested_execute_1
execute as @s[tag=ulg.bp.carry] unless data entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".bp run function ulg:bp/tick/nested_execute_2
execute if score @s ulg_bp_coas matches 1.. run function ulg:bp/tick/nested_execute_3

execute as @s[gamemode=survival] run function ulg:bp/tick/check_backpack_limit
execute as @s[gamemode=!survival,tag=ulg_bp_slowness] run effect clear @s minecraft:slowness
execute as @s[gamemode=!survival,tag=ulg_bp_slowness] run tag @s remove ulg_bp_slowness
