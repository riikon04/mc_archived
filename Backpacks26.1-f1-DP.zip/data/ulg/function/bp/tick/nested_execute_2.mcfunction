execute at @s run playsound minecraft:item.armor.equip_leather player @a[distance=..3] ~ ~ ~ 1 1 0.1
tag @s remove ulg.bp.carry
