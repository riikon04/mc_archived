execute as @s[tag=!global.ignore, nbt={Item: {components: {"minecraft:custom_data": {bp: {Opened: 1b}}}}}] at @s run function ulg:bp/sub/convert_openedbackpacks/item_tag_entity_case
execute if score $CAN_PLACE_BACKPACKS ulg_gen matches 1 as @s[tag=!global.ignore, nbt={Item: {components: {"minecraft:custom_data": {bp: {Opened: 0b}}}}}] at @s if block ~ ~-0.2 ~ #ulg:bp/tick/tables run function ulg:bp/tick/nested_execute_0
execute as @s[tag=!global.ignore, nbt={Item: {components: {"minecraft:custom_data": {ulg: {BackPack: {}}}}}}] at @s if block ~ ~-0.3 ~ #ulg:bp/tick/tables align xyz positioned ~0.5 ~ ~0.5 run function ulg:bp/sub/benching/tryplace
execute if score $TABLE_BACKPACKS_TICK ulg_gen matches 1 as @s[type=minecraft:armor_stand, tag=ulg.backpackModifiable] at @s run function ulg:bp/sub/benching/asbackpack
execute as @s[type=player] at @s run function ulg:bp/tick/nested_execute_4
