scoreboard objectives add rcms_tick dummy
scoreboard objectives add rcms_rng dummy
scoreboard players set #spawn_timer rcms_tick 0
