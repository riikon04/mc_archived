tag @s add MusicSellerInit
data merge entity @s {CustomName:'"MusicSeller"',CustomNameVisible:1b,Silent:0b}
function riikon_custom:music_seller/set_offers
