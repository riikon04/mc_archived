# Mark as initialized to prevent re-processing
tag @s add MusicSellerInit

# Set custom name and behavior (1.21.5+ format: JSON text component)
data merge entity @s {CustomName:'{"text":"MusicSeller"}',CustomNameVisible:1b,Silent:0b}

# Add floating jukebox display above villager (1.21.5+ block_state format)
data modify entity @s Passengers append value {id:"minecraft:block_display",Tags:["MusicSellerDisplay"],block_state:{name:"minecraft:jukebox"},transformation:{translation:[0.0f,2.1f,0.0f],left_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[0.45f,0.45f,0.45f],right_rotation:[0.0f,0.0f,0.0f,1.0f]},brightness:{sky:15,block:15},view_range:0.6f,shadow_radius:0.0f,shadow_strength:0.0f}

# Apply music disc trades
function riikon_custom:music_seller/set_offers
