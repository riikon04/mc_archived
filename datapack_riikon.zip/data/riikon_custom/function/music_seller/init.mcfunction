data merge entity @s {VillagerData:{profession:"minecraft:librarian",level:5,type:"minecraft:plains"},CustomName:'"MusicSeller"',CustomNameVisible:1b,Silent:0b}
tag @s add MusicSellerInit
function riikon_custom:music_seller/set_offers
