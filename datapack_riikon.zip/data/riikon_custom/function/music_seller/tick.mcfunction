scoreboard players add #spawn_timer rcms_tick 1

tag @e[type=villager,name="MusicSeller",tag=!MusicSeller] add MusicSeller
tag @e[type=villager,tag=MusicSellerChosen,tag=!MusicSeller] remove MusicSellerChosen
execute as @e[type=villager,tag=MusicSeller,tag=!MusicSellerInit] run function riikon_custom:music_seller/init

execute if score #spawn_timer rcms_tick matches 1200.. run function riikon_custom:music_seller/spawn_roll

execute if score #spawn_timer rcms_tick matches 1200.. run scoreboard players set #spawn_timer rcms_tick 0
