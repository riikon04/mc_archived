scoreboard players add #spawn_timer rcms_tick 1

# === Detect named "MusicSeller" villagers ===
# Method 1: name= selector (works in most versions)
tag @e[type=villager,name="MusicSeller",tag=!MusicSeller] add MusicSeller
# Method 2: NBT detection - JSON text component format (1.21.5+)
execute as @e[type=villager,tag=!MusicSeller] at @s if data entity @s {CustomName:'{"text":"MusicSeller"}'} run tag @s add MusicSeller
# Method 3: NBT detection - JSON string format (older versions)
execute as @e[type=villager,tag=!MusicSeller] at @s if data entity @s {CustomName:'"MusicSeller"'} run tag @s add MusicSeller

tag @e[type=villager,tag=MusicSellerChosen,tag=!MusicSeller] remove MusicSellerChosen
execute as @e[type=villager,tag=MusicSeller,tag=!MusicSellerInit] run function riikon_custom:music_seller/init

execute if score #spawn_timer rcms_tick matches 1200.. run function riikon_custom:music_seller/spawn_roll

execute if score #spawn_timer rcms_tick matches 1200.. run scoreboard players set #spawn_timer rcms_tick 0
