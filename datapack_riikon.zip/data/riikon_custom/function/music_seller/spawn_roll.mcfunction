execute store result score #spawn rcms_rng run random value 1..1000
execute if score #spawn rcms_rng matches 1..20 as @a[sort=random,limit=1] at @s unless entity @e[type=villager,tag=MusicSeller,distance=..96] run summon villager ~2 ~ ~2 {Tags:["MusicSeller"],NoAI:0b,Invulnerable:0b,PersistenceRequired:1b}
