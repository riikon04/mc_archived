data modify entity @s Offers.Recipes set value []
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:stick",count:1},sell:{id:"minecraft:music_disc_11",count:1,components:{"minecraft:jukebox_playable":"riikon_custom:color_your_night"}},maxUses:999999,rewardExp:0b}
