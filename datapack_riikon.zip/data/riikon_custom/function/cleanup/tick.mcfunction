scoreboard players add #tick rc_cleanup_tick 1
execute if score #tick rc_cleanup_tick matches 20.. run function riikon_custom:cleanup/second_step
