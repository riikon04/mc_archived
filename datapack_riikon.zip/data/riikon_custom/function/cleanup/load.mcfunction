scoreboard objectives add rc_cleanup_tick dummy
scoreboard objectives add rc_cleanup_sec dummy
scoreboard players set #tick rc_cleanup_tick 0
scoreboard players set #sec rc_cleanup_sec 180
