scoreboard players set #tick rc_cleanup_tick 0
scoreboard players remove #sec rc_cleanup_sec 1

execute if score #sec rc_cleanup_sec matches 1..30 run tellraw @a [{"text":"[Cleanup] ","color":"red"},{"text":"Con "},{"score":{"name":"#sec","objective":"rc_cleanup_sec"}},{"text":"s nữa sẽ xóa các item rơi vãi trên map."}]

execute if score #sec rc_cleanup_sec matches ..0 run kill @e[type=item]
execute if score #sec rc_cleanup_sec matches ..0 run tellraw @a {"text":"[Cleanup] Đã xóa các item drop.","color":"gold"}
execute if score #sec rc_cleanup_sec matches ..0 run scoreboard players set #sec rc_cleanup_sec 180
