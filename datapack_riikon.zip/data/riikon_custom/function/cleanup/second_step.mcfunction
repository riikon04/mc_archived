scoreboard players set #tick rc_cleanup_tick 0
scoreboard players remove #sec rc_cleanup_sec 1

execute if score #sec rc_cleanup_sec matches 30 run tellraw @a {"text":"[Cleanup] 30s nữa sẽ xóa các item rơi vãi trên map.","color":"gold"}
execute if score #sec rc_cleanup_sec matches 5 run tellraw @a {"text":"[Cleanup] 5s nữa sẽ xóa các item rơi vãi trên map.","color":"gold"}

execute if score #sec rc_cleanup_sec matches ..0 run kill @e[type=item,tag=!RCNoClean,tag=!fkbm.totem,nbt=!{NoGravity:1b},nbt=!{Item:{components:{"minecraft:custom_data":{fkbm:{totem:1b}}}}}]
execute if score #sec rc_cleanup_sec matches ..0 run tellraw @a {"text":"[Cleanup] Đã xóa các item drop.","color":"gold"}
execute if score #sec rc_cleanup_sec matches ..0 run scoreboard players set #sec rc_cleanup_sec 300
