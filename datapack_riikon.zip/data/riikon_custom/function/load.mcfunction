scoreboard objectives add deadcount deathCount "Số lần chết"
scoreboard objectives setdisplay list deadcount
