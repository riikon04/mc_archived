execute if block ~ ~ ~ minecraft:jukebox unless entity @e[type=marker,tag=RJK,distance=..1.3] run summon marker ~0.5 ~0.5 ~0.5 {Tags:["RJK"]}
