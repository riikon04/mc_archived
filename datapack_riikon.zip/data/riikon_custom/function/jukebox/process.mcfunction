execute if score @s rjk_state matches 0 if block ~ ~ ~ minecraft:jukebox[has_record=true] run function riikon_custom:jukebox/start
execute if score @s rjk_state matches 1 run function riikon_custom:jukebox/playing
execute if score @s rjk_state matches 0 unless block ~ ~ ~ minecraft:jukebox[has_record=true] if block ~ ~1 ~ minecraft:hopper if data block ~ ~1 ~ {Items:[{Slot:0b}]} run function riikon_custom:jukebox/pull_from_hopper
