data modify storage riikon_custom:jukebox item set from block ~ ~ ~ RecordItem
data remove block ~ ~ ~ RecordItem
execute if data storage riikon_custom:jukebox {item:{}} run summon item ~ ~0.2 ~ {Tags:["RJKDrop"],PickupDelay:0s}
execute if entity @e[type=item,tag=RJKDrop,distance=..1,limit=1] run data modify entity @e[type=item,tag=RJKDrop,distance=..1,limit=1,sort=nearest] Item set from storage riikon_custom:jukebox item
tag @e[type=item,tag=RJKDrop,distance=..2] remove RJKDrop
function riikon_custom:jukebox/reset
execute if block ~ ~1 ~ minecraft:hopper if data block ~ ~1 ~ {Items:[{Slot:0b}]} run function riikon_custom:jukebox/pull_from_hopper
