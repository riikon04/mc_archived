scoreboard objectives add rjk_state dummy
scoreboard objectives add rjk_elapsed dummy
scoreboard objectives add rjk_length dummy
