execute at @s align xyz if block ~ ~-1 ~ minecraft:jukebox unless entity @e[type=marker,tag=RJK,distance=..0.8] run summon marker ~0.5 ~-1 ~0.5 {Tags:["RJK"]}
execute as @e[type=marker,tag=RJK,tag=!RJKInit] run function riikon_custom:jukebox/register_init
