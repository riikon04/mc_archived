function riikon_custom:jukebox/auto_register
execute as @e[type=marker,tag=RJK] at @s unless block ~ ~ ~ minecraft:jukebox run function riikon_custom:jukebox/remove
execute as @e[type=marker,tag=RJK] at @s if block ~ ~ ~ minecraft:jukebox run function riikon_custom:jukebox/process
