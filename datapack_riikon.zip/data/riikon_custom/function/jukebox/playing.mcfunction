execute unless block ~ ~ ~ minecraft:jukebox[has_record=true] run function riikon_custom:jukebox/reset
execute if block ~ ~ ~ minecraft:jukebox[has_record=true] run scoreboard players add @s rjk_elapsed 1
execute if block ~ ~ ~ minecraft:jukebox[has_record=true] if score @s rjk_elapsed >= @s rjk_length run function riikon_custom:jukebox/eject
