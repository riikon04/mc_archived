scoreboard players set @s rjk_state 1
scoreboard players set @s rjk_elapsed 0
scoreboard players set @s rjk_length 2400
function riikon_custom:jukebox/set_length
