tag @s add RJKInit
scoreboard players set @s rjk_state 0
scoreboard players set @s rjk_elapsed 0
scoreboard players set @s rjk_length 0
