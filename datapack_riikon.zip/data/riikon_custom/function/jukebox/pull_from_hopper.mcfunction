data modify storage riikon_custom:jukebox incoming set from block ~ ~1 ~ Items[{Slot:0b}]
execute if data storage riikon_custom:jukebox {incoming:{id:"minecraft:music_disc_11"}} run data modify block ~ ~ ~ RecordItem set from storage riikon_custom:jukebox incoming
execute if data storage riikon_custom:jukebox {incoming:{id:"minecraft:music_disc_11"}} run data remove block ~ ~ ~ RecordItem.Slot
execute if data storage riikon_custom:jukebox {incoming:{id:"minecraft:music_disc_11"}} run item replace block ~ ~1 ~ container.0 with air
