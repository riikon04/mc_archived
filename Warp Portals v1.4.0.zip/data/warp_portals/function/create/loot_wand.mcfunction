
loot spawn ~ ~ ~ loot warp_portals:gameplay/portal_wand

execute as @s store result entity @e[type=item,nbt={Item:{id:"minecraft:shulker_spawn_egg"}},sort=nearest,limit=1] Item.components."minecraft:entity_data".data.PortalWandX int 1 run scoreboard players get @s warp_portals.portal_x
execute as @s store result entity @e[type=item,nbt={Item:{id:"minecraft:shulker_spawn_egg"}},sort=nearest,limit=1] Item.components."minecraft:entity_data".data.PortalWandY int 1 run scoreboard players get @s warp_portals.portal_y
execute as @s store result entity @e[type=item,nbt={Item:{id:"minecraft:shulker_spawn_egg"}},sort=nearest,limit=1] Item.components."minecraft:entity_data".data.PortalWandZ int 1 run scoreboard players get @s warp_portals.portal_z
execute as @s store result entity @e[type=item,nbt={Item:{id:"minecraft:shulker_spawn_egg"}},sort=nearest,limit=1] Item.components."minecraft:entity_data".data.PortalWandDim int 1 run scoreboard players get @s warp_portals.portal_dim

execute if score @s warp_portals.portal_dim matches 2 as @e[type=item,nbt={Item:{id:"minecraft:shulker_spawn_egg"}},sort=nearest,limit=1] run data modify entity @s Item.components."minecraft:lore" append value "{\"text\":\"The Nether\"}"
execute if score @s warp_portals.portal_dim matches 3 as @e[type=item,nbt={Item:{id:"minecraft:shulker_spawn_egg"}},sort=nearest,limit=1] run data modify entity @s Item.components."minecraft:lore" append value "{\"text\":\"The End\"}"
