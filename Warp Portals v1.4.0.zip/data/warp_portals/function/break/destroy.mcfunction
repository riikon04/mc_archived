summon item ~ ~1 ~ {Motion:[0.0,0.2,0.0],Item:{id:"minecraft:ender_pearl",count:1},Tags:["warp_portals.ignore"]}
playsound minecraft:block.glass.break neutral @a ~ ~ ~ 1
kill @s
