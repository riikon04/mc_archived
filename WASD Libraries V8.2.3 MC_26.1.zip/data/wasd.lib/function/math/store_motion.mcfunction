function wasd.lib:math/get_motion
execute store result storage minecraft:wasd.lib_storage motion_0 double 0.000001 run scoreboard players get @n[tag=wasd.get_motion] wasd.motion_posx
execute store result storage minecraft:wasd.lib_storage motion_1 double 0.000001 run scoreboard players get @n[tag=wasd.get_motion] wasd.motion_posy
execute store result storage minecraft:wasd.lib_storage motion_2 double 0.000001 run scoreboard players get @n[tag=wasd.get_motion] wasd.motion_posz

kill @n[tag=wasd.get_motion]
