function wasd.lib:math/get_motion
execute store result entity @s Motion[0] double 0.000001 run scoreboard players get @n[tag=wasd.get_motion] wasd.motion_posx
execute store result entity @s Motion[1] double 0.000001 run scoreboard players get @n[tag=wasd.get_motion] wasd.motion_posy
execute store result entity @s Motion[2] double 0.000001 run scoreboard players get @n[tag=wasd.get_motion] wasd.motion_posz

kill @n[tag=wasd.get_motion]
execute as @s[type=item] run data merge entity @s {NoGravity:1b,Tags:["wasd.item_given_motion"]}
schedule function wasd.lib:math/fix_motion 2t
