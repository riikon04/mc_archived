summon minecraft:area_effect_cloud ~ ~ ~ {custom_particle:{type:"block",block_state:"minecraft:air"},Duration:10,Tags:["wasd.get_motion"]}

execute store result score @s wasd.motion_posx run data get entity @s Pos[0] 100000
execute store result score @s wasd.motion_posy run data get entity @s Pos[1] 100000
execute store result score @s wasd.motion_posz run data get entity @s Pos[2] 100000

execute as @n[tag=wasd.get_motion] store result score @s wasd.motion_posx run data get entity @s Pos[0] 100000
execute as @n[tag=wasd.get_motion] store result score @s wasd.motion_posy run data get entity @s Pos[1] 100000
execute as @n[tag=wasd.get_motion] store result score @s wasd.motion_posz run data get entity @s Pos[2] 100000

scoreboard players operation @n[tag=wasd.get_motion] wasd.motion_posx -= @s wasd.motion_posx
scoreboard players operation @n[tag=wasd.get_motion] wasd.motion_posy -= @s wasd.motion_posy
scoreboard players operation @n[tag=wasd.get_motion] wasd.motion_posz -= @s wasd.motion_posz



